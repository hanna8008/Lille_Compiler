/*

id_table_entry.o:  id_table_entry.h id_table_entry.cpp
	g++ -std=c++2a -c id_table_entry.cpp

 * parser.cpp
 *
 *  Created on: November 10, 2023
 *      Author: Hanna Zelis
 */

#include <iostream>
#include <fstream>
#include <filesystem>
#include <string>
#include <cctype>
#include <cmath>
#include <list>

#include "symbol.h"
#include "scanner.h"
#include "error_handler.h"
#include "token.h"
#include "parser.h"
#include "lille_exception.h"
#include "id_table.h"
#include "id_table_entry.h"

using namespace std;

//syntax function = part of the scheme 1 error recovery in lecture 16 slides 11-15
/*bool recovering = false;
void parser::syntax()
{
    if (!recovering)
        error->flag(current_line_number, current_pos_on_line, 129);

    recovering = true;
}


//final function for error recovery - scheme #1
void parser::must_be(symbol::symbol_type s)
{
    if (recovering)
    {
        while ((current_token->get_sym() != s) and (current_token->get_sym() != end_of_program))   
        {
            get_token();
        }

        if (current_token->get_sym() == s)
        {
            get_token();
        }

        recovering = false;
    }

    else if (current_token->get_sym() == s)
    {
        get_token();
    }

    else{
		error->flag(current_token, error_message(s));
    }

}*/



//constructor with no parameters
parser::parser()
{
    err = NULL;
    scan = NULL;
    id_tab = NULL;
}



//constructor with parameters
parser::parser(scanner* scan, id_table* id_tab, error_handler* err) : scan(scan), err(err)
{
    this -> err = err;
    this -> scan = scan;
    this -> id_tab = id_tab;

    scan -> get_token();
    parser();
}



//constructor to start the scanner
/*parser::parser(scanner* scan)
{
    prog();
}*/



//<prog> function
void parser::prog()
{
    //scan->get_token();

    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <prog> method" << endl;
    }

    //check and throw away tokens
    scan -> get_token();    //new 

    scan -> must_be(symbol::program_sym);

    scan -> must_be(symbol::identifier);  

    scan -> must_be(symbol::is_sym);

    block();

    scan -> must_be(symbol::semicolon_sym); 

    /*if (scan -> have(symbol::end_of_program))
    {
        scan -> must_be(symbol::end_of_program);
    }*/

    //turn of debugger
    if (debugging)
    {
        cout << "End: <prog> method" << endl;
    }

}



//<block> function
void parser::block()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <block> method" << endl;
    }

    id_tab->enter_scope();

    //check these parameters of declaration, and if any of them occur, run this function
    while (scan -> have(symbol::identifier) || scan -> have(symbol::procedure_sym) || scan -> have(symbol::function_sym))
    {
        //scan->get_token();
        declaration();
    }

    //check and throw away tokens
    scan -> must_be(symbol::begin_sym);   

    statement_list();

    scan -> must_be(symbol::end_sym);       

    if (scan -> have(symbol::identifier))  
    {
        scan -> must_be(symbol::identifier);
        //scan -> get_token();
    }

    id_tab->exit_scope();

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <block> method" << endl;
    }
}



//<declaration> function 
void parser::declaration()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <declaration> method" << endl;
    }

    
    if (scan -> have(symbol::identifier))
    {
    ident_list();

    scan -> must_be(symbol::colon_sym);

        if (scan -> have(symbol::constant_sym))
        {
            scan -> must_be(symbol::constant_sym);
        }
    

    type();

    if (scan -> have(symbol::becomes_sym))
    {
        scan -> must_be(symbol::becomes_sym);
        if ( (scan->have(symbol::integer)) || (scan->have(symbol::strng)) || (scan->have(symbol::real_num)) || 
            (scan->have(symbol::true_sym)) || (scan->have(symbol::false_sym)) )
        {
            scan->get_token();
        }
        else
        {
            err->flag(scan->this_token(), 69);
        }


        }
        scan -> must_be(symbol::semicolon_sym);
    }


    else if (scan -> have(symbol::procedure_sym))
    {
        scan -> must_be(symbol::procedure_sym);
        scan -> must_be(symbol::identifier);

        if (scan -> have(symbol::left_paren_sym)){
            scan -> must_be(symbol::left_paren_sym);
            param_list();
            scan -> must_be(symbol::right_paren_sym);
        }
        scan -> must_be(symbol::is_sym);
        block();
        scan -> must_be(symbol::semicolon_sym);
    }

    else if (scan -> have(symbol::function_sym))
    {
        scan -> must_be(symbol::function_sym);
        scan -> must_be(symbol::identifier);

        if (scan -> have(symbol::left_paren_sym)){
            scan -> must_be(symbol::left_paren_sym);
            param_list();
            scan -> must_be(symbol::right_paren_sym);
        }

        scan -> must_be(symbol::return_sym);
        type();
        scan -> must_be(symbol::is_sym);
        block();
        scan -> must_be(symbol::semicolon_sym);
    }
    else{
        err->flag(scan->this_token(), 0);
    }



    /*else
    {
        err -> flag(scan->this_token(), 106);
    }*/

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <declaration> method" << endl;
    }  
}



//<type> function
void parser::type()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <type> method" << endl;
    }

    if (scan -> have (symbol::integer_sym))
    {
        scan -> must_be(symbol::integer_sym);
    }

    else if (scan -> have(symbol::real_sym))
    {
        scan -> must_be(symbol::real_sym);
    }

    else if (scan -> have(symbol::string_sym))
    {
        scan -> must_be(symbol::string_sym);
    }
    
    else if (scan -> have(symbol::boolean_sym))
    {
        scan -> must_be(symbol::boolean_sym);
    }

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <type> method" << endl;
    }  
}



//<param_list> function
void parser::param_list()
{
    //turn on debugger
    if (debugging){
        cout << "Enter: <param_list> method" << endl;
    }

    param();

    while(scan -> have(symbol::semicolon_sym))
    {
        scan -> must_be(symbol::semicolon_sym);
        param();
    }

    /*
       // Initializing variables for parameter building
    int count = 0;
    parameter* ptr = NULL;
    lille_type ty;
    lille_kind knd;

    // Loop to build a list of parameters
    while (scan->have(symbol::identifier)) {
        // Get the parameter type
        ty = type();
        // Determine the parameter kind (value or ref)
        if (scan->have(symbol::value_sym)) {
            scan->must_be(symbol::value_sym);
            knd = lille_kind::value_parameter;
        } else if (scan->have(symbol::ref_sym)) {
            scan->must_be(symbol::ref_sym);
            knd = lille_kind::ref_parameter;
        } else {
            knd = lille_kind::unknown;
        }

        // Creating parameter ID and adding it to the ID table
        id_table_entry* param_id = new id_table_entry(scan->this_token(), ty, knd, id_tab->scope(), current_offset, lille_type::type_unknown);
        id_tab->add_table_entry(param_id);
        id->add_param(param_id);
        
        count++;

        // Move to the next token if available
        scan->get_token();
        
        // Check if there are more parameters to process
        if (scan->have(symbol::comma_sym)) {
            scan->must_be(symbol::comma_sym);
        } else {
            break;
        }
    }

    // Perform additional operations if needed based on the created parameter list
    // …
    // …
    // …
    // …
    // …
    // …


    // Loop through the parameters to finalize their entries
    ptr = list;
    while ((ptr != NULL) && (count > 0)) {
        param_id = new id_table_entry(ptr->val, ty, knd, id_tab->scope(), current_offset, lille_type::type_unknown);
        id_tab->add_table_entry(param_id);
        id->add_param(param_id);
        count--;

        if (ptr->next != NULL) {
            ptr = ptr->next;
        }
    }
    */


    //turn of debugger
    if (debugging) 
    {
        cout << "End: <param_list> method" << endl;
    }  
}



//<param> function
void parser::param()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <param> method" << endl;
    }

    ident_list();

    scan -> must_be(symbol::colon_sym);

    param_kind();

    type();

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <param> method" << endl;
    }  
}



//<ident_list> function
void parser::ident_list()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <ident_list> method" << endl;
    }

    scan -> must_be(symbol::identifier); // this or scan -> must_be(symbol::identifier);

    while(scan -> have(symbol::comma_sym))
    {
        scan -> must_be(symbol::comma_sym);
        scan -> must_be(symbol::identifier);
    }

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <ident_list> method" << endl;
    }  
}



//<param_kind> function
void parser::param_kind()
{
   //turn on debugger
    if (debugging)
    {
        cout << "Enter: <param_kind> method" << endl;
    }

    if (scan -> have(symbol::value_sym))
    {
        scan -> must_be(symbol::value_sym);
    }
    
    else if (scan -> have(symbol::ref_sym))
    {
        scan -> must_be(symbol::ref_sym);
    }

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <param_kind> method" << endl;
    }   
}



//<statement_list> function
void parser::statement_list()
{
   //turn on debugger
    if (debugging)
    {
        cout << "Enter: <statement_list> method" << endl;
    }

    statement();

    //scan -> must_be(symbol::semicolon_sym);

    while (scan -> have(symbol::identifier) || scan -> have(symbol::exit_sym) || scan -> have(symbol::return_sym) 
    || scan -> have(symbol::read_sym) || scan -> have(symbol::write_sym) || scan -> have(symbol::writeln_sym) || scan -> have(symbol::null_sym) 
    || scan -> have(symbol::if_sym)         // if_statement
        || scan -> have(symbol::while_sym)       // loop_statement
        || scan -> have(symbol::for_sym)       //for_statement
        || scan -> have(symbol::loop_sym) )   //while_statement*/
    {
        statement();
        scan -> must_be(symbol::semicolon_sym);
    }

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <statement_list> method" << endl;
    }  
}



//<statement> function
void parser::statement()
{
    //turn on debugger
    if (debugging){
        cout << "Enter: <statement> method" << endl;
    }

    if (scan -> have(symbol::identifier) || scan -> have(symbol::exit_sym) || scan -> have(symbol::return_sym) || scan -> have(symbol::read_sym) || scan -> have(symbol::write_sym) || scan -> have(symbol::writeln_sym) || scan -> have(symbol::null_sym))
    {
        simple_statement();
    }

    else if (scan -> have(symbol::if_sym) || (scan -> have(symbol::while_sym)) || scan -> have(symbol::for_sym) || scan -> have(symbol::loop_sym))
    {
        compound_statement();
    }

    //turn of debugger
    if (debugging) {
        cout << "End: <statement> method" << endl;
    }  
}



void parser::simple_statement(){

    //turn on debugger
    if (debugging) 
    {
        cout << "Enter: <statement> method" << endl;
    }  
   
   if (scan -> have(symbol::identifier))
{ 
   scan -> must_be(symbol::identifier);
   
   if (scan -> have(symbol::left_paren_sym))
   {
       scan -> must_be(symbol::left_paren_sym);
       //plus_sym, minus_sym, not_sym, odd, left_paren, identifier, inteer, real_num, strng, true_sym, false_sum
       if (scan -> have(symbol::plus_sym) || scan -> have(symbol::minus_sym) || scan -> have(symbol::not_sym) || scan -> have(symbol::odd_sym) || (scan -> have(symbol::left_paren_sym))
            || scan -> have(symbol::identifier) || scan -> have(symbol::integer) || scan -> have(symbol::real_num) 
            || scan -> have(symbol::strng) || scan -> have(symbol::true_sym) || scan -> have(symbol::false_sym)) 
        {
            expr();
            while (scan -> have(symbol::comma_sym))
            {
                scan -> must_be(symbol::comma_sym);
                expr();
            } 
        }
        scan -> must_be(symbol::right_paren_sym);
   }
   
   else if (scan -> have(symbol::becomes_sym))
   {
       scan -> must_be(symbol::becomes_sym);
       expr();
   }
}
   
   else if (scan -> have(symbol::exit_sym))
   {
        scan -> must_be(symbol::exit_sym);
       if (scan -> have(symbol::when_sym))
       {
           scan -> must_be(symbol::when_sym);
           expr();
       }
   }

   else if (scan -> have (symbol::return_sym))
   {
        scan -> must_be(symbol::return_sym);
        //plus_sym, minus_sym, not_sym, odd, left_paren, identifier, inteer, real_num, strng, true_sym, false_sum
        if (scan -> have(symbol::plus_sym) || scan -> have(symbol::minus_sym) || scan -> have(symbol::not_sym) || scan -> have(symbol::odd_sym) || (scan -> have(symbol::left_paren_sym))
            || scan -> have(symbol::identifier) || scan -> have(symbol::integer) || scan -> have(symbol::real_num) 
            || scan -> have(symbol::strng) || scan -> have(symbol::true_sym) || scan -> have(symbol::false_sym)) 
        {
            expr();
        }
   
   }
   

   else if (scan -> have(symbol::read_sym))
   {
        scan -> must_be(symbol::read_sym);
       if (scan -> have(symbol::left_paren_sym))
       {
           scan -> must_be(symbol::left_paren_sym);
           ident_list();
           scan -> must_be(symbol::right_paren_sym);
       }

        else{
            ident_list();
        }
   }

   else if (scan -> have(symbol::write_sym))
    {
        scan->must_be(symbol::write_sym);
        if (scan->have(symbol::left_paren_sym))
        {
            scan->must_be(symbol::left_paren_sym);
            if (scan->have(symbol::plus_sym) || scan->have(symbol::minus_sym) ||
                 scan->have(symbol::not_sym) || scan->have(symbol::odd_sym) || 
                 scan->have(symbol::left_paren_sym) || scan->have(symbol::identifier) || 
                 scan->have(symbol::integer) || scan->have(symbol::real_num) ||
                 scan->have(symbol::strng) || scan->have(symbol::true_sym) ||
                 scan->have(symbol::false_sym) )
            {
                expr();
                while(scan->have(symbol::comma_sym))
                {
                    scan->must_be(symbol::comma_sym);
                    expr();
                }
            }
            scan->must_be(symbol::right_paren_sym);
        }
        else
        {
            if (scan->have(symbol::plus_sym) || scan->have(symbol::minus_sym) ||
                 scan->have(symbol::not_sym) || scan->have(symbol::odd_sym) || 
                 scan->have(symbol::left_paren_sym) || scan->have(symbol::identifier) || 
                 scan->have(symbol::integer) || scan->have(symbol::real_num) ||
                 scan->have(symbol::strng) || scan->have(symbol::true_sym) ||
                 scan->have(symbol::false_sym))
            {
                expr();
                while(scan->have(symbol::comma_sym))
                {
                    scan->must_be(symbol::comma_sym);
                    expr();
                }
            }
        }
    }

   else if (scan -> have(symbol::writeln_sym))
   {
        scan -> must_be(symbol::writeln_sym);
        if (scan -> have(symbol::left_paren_sym))
        {
           scan -> must_be(symbol::left_paren_sym);
           //plus_sym, minus_sym, not_sym, odd, left_paren, identifier, inteer, real_num, strng, true_sym, false_sum
           if (scan -> have(symbol::plus_sym) || scan -> have(symbol::minus_sym) || scan -> have(symbol::not_sym) || scan -> have(symbol::odd_sym) || (scan -> have(symbol::left_paren_sym))
            || scan -> have(symbol::identifier) || scan -> have(symbol::integer) || scan -> have(symbol::real_num) 
            || scan -> have(symbol::strng) || scan -> have(symbol::true_sym) || scan -> have(symbol::false_sym)) 
            {
                expr();
            }
        }

        else if (scan -> have(symbol::plus_sym) || scan -> have(symbol::minus_sym) || scan -> have(symbol::not_sym) || scan -> have(symbol::odd_sym) || (scan -> have(symbol::left_paren_sym))
            || scan -> have(symbol::identifier) || scan -> have(symbol::integer) || scan -> have(symbol::real_num) 
            || scan -> have(symbol::strng) || scan -> have(symbol::true_sym) || scan -> have(symbol::false_sym))    //walk from <expr>
        {
            scan->get_token();
            expr();
       
            while(scan -> have(symbol::comma_sym))
            {
                scan -> must_be(symbol::comma_sym);
                if (scan -> have(symbol::plus_sym) || scan -> have(symbol::minus_sym) || scan -> have(symbol::not_sym) || scan -> have(symbol::odd_sym) || (scan -> have(symbol::left_paren_sym))
                    || scan -> have(symbol::identifier) || scan -> have(symbol::integer) || scan -> have(symbol::real_num) 
                    || scan -> have(symbol::strng) || scan -> have(symbol::true_sym) || scan -> have(symbol::false_sym)) 
                {
                    expr();
                }
            }
        }

        if (scan -> have(symbol::right_paren_sym))
        {
            scan -> must_be(symbol::right_paren_sym);
        }

   }

   else if (scan -> have(symbol::null_sym))
       {
           scan -> must_be(symbol::null_sym);
       }

   //turn of debugger
    if (debugging) {
           cout << "End: <statement> method" << endl;
    }  


}





//<compound_statement> function
void parser::compound_statement(){
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <compound_statement> method" << endl;
    }

    if (scan -> have(symbol::if_sym)){
        scan -> must_be(symbol::if_sym);
    }

    else if (scan -> have(symbol::loop_sym)){
        scan -> must_be(symbol::loop_sym);
    }

    else if (scan -> have(symbol::for_sym)){
        scan -> must_be(symbol::for_sym);
    }

    else if (scan -> have(symbol::while_sym)){
        scan -> must_be(symbol::while_sym);
    }

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <compound_statement> method" << endl;
    }  
}



//<if_statement> function
void parser::if_statement()
{
  //turn on debugger
    if (debugging)
    {
        cout << "Enter: <if_statement> method" << endl;
    }

    scan -> must_be(symbol::if_sym);

    expr();

    scan -> must_be(symbol::then_sym);

    statement_list();

    while (scan -> have(symbol::elsif_sym))
    {
        scan -> must_be(symbol::elsif_sym);
        expr();
        scan -> must_be(symbol::then_sym);
        statement_list();
    }

    if (scan -> have(symbol::else_sym))
    {
        scan -> must_be(symbol::else_sym);
        statement_list();
    }

    scan -> must_be(symbol::end_sym);
    
    scan -> must_be(symbol::if_sym);

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <if_statement> method" << endl;
    }  
}



//<while_statement> function
void parser::while_statement()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <while_statement> method" << endl;
    }

    scan -> must_be(symbol::while_sym);

    expr();

    loop_statement();

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <while_statement> method" << endl;
    }  
}



//<for_statement> function
void parser::for_statement()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <for_statement> method" << endl;
    }

    scan -> must_be(symbol::for_sym);

    scan -> must_be(symbol::identifier);

    scan -> must_be(symbol::in_sym);

    if (scan -> have(symbol::reverse_sym))
    {
        scan -> must_be(symbol::reverse_sym);
    }

    range();

    loop_statement();

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <for_statement> method" << endl;
    } 
}



//<loop_statement> function
void parser::loop_statement()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <loop_statement> method" << endl;
    }

    scan -> must_be(symbol::loop_sym);

    statement_list();

    scan -> must_be(symbol::end_sym);

    scan -> must_be(symbol::loop_sym);

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <loop_statement> method" << endl;
    } 
}



//<range> function
void parser::range()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <range> method" << endl;
    }

    simple_expr();

    scan -> must_be(symbol::range_sym);

    simple_expr();

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <range> method" << endl;
    } 
}



//<expr> function
void parser::expr()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <expr> method" << endl;
    }

    simple_expr();

    if (scan -> have(symbol::greater_than_sym) || scan -> have(symbol::less_than_sym)
        || scan -> have(symbol::equals_sym) || scan -> have(symbol::not_equals_sym)
        || scan -> have(symbol::less_or_equal_sym) || scan -> have(symbol::greater_or_equal_sym))
    {
        //scan->get_token();
        relop();
        simple_expr();
    }

    else if (scan -> have(symbol::in_sym))
    {
        scan -> must_be(symbol::in_sym);
        range();
    }

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <expr> method" << endl;
    } 
}



//<bool> function
void parser::bool_function()
{
    //turn on debugger
    if (debugging){
        cout << "Enter: <bool_function> method" << endl;
    }

    if (scan -> have(symbol::true_sym))
    {
        scan -> must_be(symbol::true_sym);
    }

    else if (scan -> have(symbol::false_sym))
    {
        scan -> must_be(symbol::false_sym);
    }

    //turn of debugger
    if (debugging) {
        cout << "End: <bool_function> method" << endl;
    } 
}



//<relop> function
void parser::relop()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <relop> method" << endl;
    }

    if (scan -> have(symbol::greater_than_sym))
    {
        scan -> must_be(symbol::greater_than_sym);
    }
    
    else if (scan -> have(symbol::less_than_sym))
    {
        scan -> must_be(symbol::less_than_sym);
    }
    
    else if (scan -> have(symbol::equals_sym))
    {
        scan -> must_be(symbol::equals_sym);
    }

    else if (scan -> have(symbol::not_equals_sym))
    {
        scan -> must_be(symbol::not_equals_sym);
    }

    else if (scan -> have(symbol::less_or_equal_sym))
    {
        scan -> must_be(symbol::less_or_equal_sym);
    }
    
    else if(scan -> have(symbol::greater_or_equal_sym))
    {
        scan -> must_be(symbol::greater_or_equal_sym);
    }

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <relop> method" << endl;
    } 
}



//<simple_expr> function
void parser::simple_expr()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <simple_expr> method" << endl;
    }

    expr2();

    while (scan -> have(symbol::ampersand_sym))
    {
        scan -> must_be(symbol::ampersand_sym);
        expr2();
    }

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <simple_expr> method" << endl;
    } 
}



//<stringop> function
void parser::stringop() 
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <stringop> method" << endl;
    }

    scan -> must_be(symbol::ampersand_sym);

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <stringop> method" << endl;
    } 
}



//<expr2> function
void parser::expr2()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <expr2> method" << endl;
    }

    term();

    while ((scan -> have(symbol::plus_sym) || scan -> have(symbol::minus_sym)) || (scan -> have(symbol::or_sym)))
    {
        if ((scan -> have(symbol::plus_sym) || scan -> have(symbol::minus_sym)))
        {
            //scan->get_token();
            addop();
        }

        else if (scan -> have(symbol::or_sym))
        {
            scan -> must_be(symbol::or_sym);
            term();
        }

        //term();
    }


    //turn of debugger
    if (debugging) 
    {
        cout << "End: <expr2> method" << endl;
    } 
}



//<addop> function
void parser::addop()
{
    //turn on debugger
    if (debugging){
        cout << "Enter: <addop> method" << endl;
    }

    if (scan -> have(symbol::plus_sym))
    {
        scan -> must_be(symbol::plus_sym);
    }
    
    else if (scan -> have(symbol::minus_sym))
    {
        scan -> must_be(symbol::minus_sym);
    }

    //turn of debugger
    if (debugging) {
        cout << "End: <addop> method" << endl;
    } 
}



//<term> function
void parser::term()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <term> method" << endl;
    }

    factor();

    while ((scan -> have(symbol::asterisk_sym) || scan -> have(symbol::slash_sym)) || (scan -> have(symbol::and_sym)))
    {
        
        if ((scan -> have(symbol::asterisk_sym) || scan -> have(symbol::slash_sym)))
        {
            //scan->get_token();
            multop();
            factor();
        }

        else if (scan -> have(symbol::and_sym))
        {
            scan -> must_be(symbol::and_sym);
            factor();
        }

        multop();
    }

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <term> method" << endl;
    }  
}



//<multop> function
void parser::multop()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <multop> method" << endl;
    }

    if (scan -> have(symbol::asterisk_sym))
    {
        scan -> must_be(symbol::asterisk_sym);
    }

    else if (scan -> have(symbol::slash_sym))
    {
        scan -> must_be(symbol::slash_sym);
    }

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <multop> method" << endl;
    } 
}



//<factor> function
void parser::factor()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <factor> method" << endl;
    }

    primary();

    if (scan -> have(symbol::power_sym))
    {
        scan -> must_be(symbol::power_sym);
        primary();
    }

    else if (scan -> have(symbol::plus_sym) || scan -> have(symbol::minus_sym))
    {
        //scan->get_token();
        addop();
        primary();
    }

    //primary();

    //turn of debugger
    if (debugging) 
    {
        cout << "End: <factor> method" << endl;
    } 
}



//<primary> function
void parser::primary()
{
    //turn on debugger
    if (debugging)
    {
        cout << "Enter: <primary> method" << endl;
    }

    if (scan -> have(symbol::not_sym))
    {
        scan -> must_be(symbol::not_sym);
        expr();
    }

    else if (scan->have(symbol::odd_sym))
    {
        scan->must_be(symbol::odd_sym);
        expr();
    }

    else if (scan->have(symbol::left_paren_sym))
    {
        scan->must_be(symbol::left_paren_sym);
        simple_expr();
        scan->must_be(symbol::right_paren_sym);
    }

    else if (scan -> have(symbol::identifier))
    {
        scan -> must_be(symbol::identifier);
        if (scan -> have(symbol::left_paren_sym))
        {
            scan -> must_be(symbol::left_paren_sym);
            expr();

            while (scan -> have(symbol::comma_sym))
            {
                scan->must_be(symbol::comma_sym);
                expr();
            }

            scan -> must_be(symbol::right_paren_sym);
        }  
    }

    
    else if (scan -> have(symbol::integer) || scan -> have(symbol::real_num))
    {
        scan->get_token();
    }

    else if (scan -> have(symbol::strng))
    {
        scan -> must_be(symbol::strng);
    }
  
    else if (scan -> have(symbol::true_sym) || scan -> have(symbol::false_sym))
    {
        scan->get_token();
    }

    
    //turn of debugger
    if (debugging) 
    {
        cout << "End: <primary> method" << endl;
    } 
}



/*//<string> function
void parser::string()
{
    //turn on debugger
    if (debugging){
        cout << "Enter: <string> method" << endl;
    }

    scan -> must_be(symbol::)

    //turn of debugger
    if (debugging) {
        cout << "End: <string> method" << endl;
    } 
}*/



/*//<ident> function
void parser::ident()
{
    //turn on debugger
    if (debugging){
        cout << "Enter: <ident> method" << endl;
    }

    

    //turn of debugger
    if (debugging) {
        cout << "End: <ident> method" << endl;
    } 
}*/



/*//<ident2> function
void parser::ident2()
{
    //turn on debugger
    if (debugging){
        cout << "Enter: <ident2> method" << endl;
    }

    

    //turn of debugger
    if (debugging) {
        cout << "End: <ident2> method" << endl;
    } 
}*/



/*//<number> function
void parser::number()
{
    //turn on debugger
    if (debugging){
        cout << "Enter: <number> method" << endl;
    }

    scan -> must_be(symbol::integer_sym) || scan -> must_be(symbol::real_num);

    //turn of debugger
    if (debugging) {
        cout << "End: <number> method" << endl;
    } 
}*/





//SEMANTIC ANALYSIS: HANDLING PREDEFINED FUNCTIONS - *insert what it does here*
void parser::predefined_routines()
{


   token* predefined_func;
   token* argument;
   symbol* predefined_sym;
   id_table_entry* func_id;
   id_table_entry* param_id;


   //Int2Real
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("INT2REAL");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, code->current_code_ptr(), lille_type::type_real);


   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__int2real_arg__");
   param_id = new id_table_entry(argument,lille_type::type_integer,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id);


   //Real2Int
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("REAL2INT");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, code->current_code_ptr(), lille_type::type_integer);


   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__real2int_arg__");
   param_id = new id_table_entry(argument,lille_type::type_real,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id);


    //Int2string
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("INT2STRING");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, code->current_code_ptr(), lille_type::type_string); //???


   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__int2string_arg__");
   param_id = new id_table_entry(argument,lille_type::type_integer,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id);


   //String2Int
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("STRING2INT");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, code->current_code_ptr(), lille_type::type_integer); //???


   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__string2int_arg__");
   param_id = new id_table_entry(argument,lille_type::type_string,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id);

} //END OF SEMANTIC ANALYSIS: HANDLING PREDEFINED FUNCTIONS





//SEMANTIC ANALAYSIS: VARIABLE DECLARATION - *insert what it does here*
void parser::variable_declaration()
{
    int count = 0;
    bool comma_found = false;
    bool const_decl = false;
    id_table_entry* id;
    lille_kind knd;
    symbol sym; 
    
    if (scan -> have(symbol::identifier)) { // variable or constant declaration
        do {
            if (scan -> have(symbol::identifier)) {
                // add ident token to list to add to ID-table when all info known.
                scan->get_token();
                count++;
            }
            comma_found = scan->have(symbol::comma_sym);
            if (comma_found)
                scan->must_be(symbol::comma_sym);
        } while (comma_found);
        
        scan->must_be(symbol::colon_sym);
        
        if (scan->have(symbol::constant_sym)) {
            const_decl = true;
            knd = lille_kind(lille_kind::constant);
            scan->must_be(symbol::constant_sym);
        } else {
            knd = lille_kind(lille_kind::variable);
        }
        
        ty = type(fsys);
        
        if (const_decl) {
            scan->must_be(symbol::becomes_sym);
            sym = scan->this_token()->get_symbol()->get_sym();
            switch (sym) {
                case symbol::real_num:
                    r_const = scan->this_token()->get_real_value();
                    if (!ty.is_type(lille_type::type_real))
                        err->flag(scan->this_token(), 111); // Const expr does not match type declaration.
                    break;
                case symbol::integer:
                    r_const = scan->this_token()->get_real_value();
                    if (!ty.is_type(lille_type::type_integer))
                        err->flag(scan->this_token(), 111); // Const expr does not match type declaration.
                    break;
                // add other cases as needed
            }
            scan->get_token();
        }    
        ptr = list;
        
        while ((ptr != NULL) and (count > 0)) {
            id = id_tab->enter_id(ptr->val, ty, knd, id_tab->scope(), current_offset, lille_type::type_unknown);
            
            if (const_decl)
                id->fix_const(i_const, r_const, s_const, b_const); // **** fix constant        
            ptr = ptr->next;
            count--;
        }
    }

} //END OF SEMANTIC ANALYSIS: VARIABLE DECLARATION





//SEMANTIC ANALYSIS: PROCEDURES AND FUNCTIONS - *insert what it does here*
void parser::procedures_and_functions() 
{
    id_table_entry* id;
    if (scan->have(symbol::function_sym)) {
        scan->must_be(symbol::function_sym);
        
        if (scan->have(symbol::identifier))
            id_table_entry* id = id_tab->enter_id(scan->this_token(), lille_type::type_func, lille_kind::unknown, id_tab->scope(), code->current_code_ptr(), lille_type::type_unknown);
            // Need to fix the return_type later once it is known.
        
        block_name = scan->this_token();
        scan->must_be(symbol::identifier);
        id_tab->enter_scope();
        
        if (scan->have(symbol::left_paren_sym)) {
            scan->must_be(symbol::left_paren_sym);
            param_list(fsys + symbol::right_paren_sym, id);
            scan->must_be(symbol::right_paren_sym);
        }
        
        scan->must_be(symbol::return_sym);
        
        if (scan->have(symbol::integer_sym)) {
            id->fix_return_type(lille_type::type_integer);
            scan->must_be(symbol::integer_sym);
        } else if (scan->have(symbol::real_sym)) {
            id->fix_return_type(lille_type::type_real);
            scan->must_be(symbol::real_sym);
        } else if (scan->have(symbol::string_sym)) {
            id->fix_return_type(lille_type::type_string);
            scan->must_be(symbol::string_sym);
        } else if (scan->have(symbol::procedure_sym)) {
            id->fix_return_type(lille_type::type_proc);
            scan->must_be(symbol::procedure_sym);
        } else if (scan->have(symbol::function_sym)) {
            id->fix_return_type(lille_type::type_func);
            scan->must_be(symbol::function_sym); 
        } else {
            err->flag(scan->this_token(), 108); // type expected.
        }
        
        scan->must_be(symbol::is_sym);
        block(fsys + symbol::semicolon_sym + symbol::identifier, block_name, return_count);
        id_tab->exit_scope();
        current_offset = old_offset;
        
        if (return_count == 0)
            err->flag(scan->this_token(), 109); // Functions must have at least 1 return statement.
        
        if (scan->have(symbol::identifier)) {
            if (block_name->get_identifier_value() != scan->this_token()->get_identifier_value())
                err->flag(scan->this_token(), 107); // Identifier must match name of the block.
            scan->must_be(symbol::identifier);
        }
    }

} //END OF SEMANTIC ANALYSIS: PROCEDURES AND FUNCTIONS 





//SEMANTIC ANALAYSIS: ASSIGNMENTS - *insert what it does here*
void parser::assignments_semantic_analysis()
{
    switch (scan->this_token()->get_symbol()->get_sym())
    {
        case symbol::identifier:
            token* tok = scan->this_token();
            id_table_entry* id_info = id_tab->lookup(tok);
            scan->must_be(symbol::identifier);

            if (scan->have(symbol::left_paren_sym))
            {
                // Better be a procedure!
                scan->must_be(symbol::left_paren_sym);

                if (!id_info->tipe().is_type(lille_type::type_proc))
                    err->flag(tok, 90);

                // Identifier must be a procedure name in this context.
                ident_list(fsys + symbol::right_paren_sym, id_info);
                scan->must_be(symbol::right_paren_sym);
            }
            else if (scan->have(symbol::becomes_sym))
            {
                // It's an assignment…
                if (!(id_info->kind().is_kind(lille_kind::variable) or id_info->kind().is_kind(lille_kind::ref_param)))
                    err->flag(tok, 85);

                // Identifier is not assignable. Must be a variable or reference parameter.
                scan->must_be(symbol::becomes_sym);

                if (expr_first_symbols.member(scan->this_token()->get_symbol()->get_sym()))
                {
                    lille_type exp_ty = expr(fsys);

                    // check LHS and RHS have matching types
                    if (!id_info->tipe().is_equal(exp_ty))
                    {
                        err->flag(scan->this_token(), 93);
                        // LHS and RHS of assignment are not type compatible.
                    }

                    if ((id_info->kind().is_kind(lille_kind::ref_param)) or (id_info->kind().is_kind(lille_kind::variable)))
                        trace_write(id_info, true);
                    else
                        err->flag(scan->this_token(), 92);
                        // String or expression expected.
                }
                else
                {
                    err->flag(tok, 91);
                    // Identifier illegal in this context.
                }
                break;
            }
    }
} //END OF SEMANTIC ANALYSIS: ASSIGNMENTS




/*
//SEMANTIC ANALYSIS: HANDLE IDENTIFIER IN AN EXPRESSION
void parser::handle_identifier_in_expr()
{
    lille_kind knd*;
    case symbol::identifier:
        tok = scan->this_token();
        id = id_tab->lookup(tok);
        return_type = id->tipe();
        knd = id->kind();

    if(symbol != nullptr)
    {
                //different kinds of identifiers
                if (symbol->isVariable())
                {
                    // Handle variable
            variable* variable = static_cast<variable*>(symbol);
            return variable->getType();

                } 
    else if(symbol->isFunction()) 
    {
                    // Handle function
                    function* function = static_cast<Function*>(symbol);
            return function->getType();
                } 
    else if(symbol->isconstant())
    {
                constant* constant = static_cast<constant*>(symbol);
            return constant->gettype();
                }
        else if(symbol->isparameter())
        {
            parameter* parameter = static_cast<parameter*>(symbol);
            return parameter->gettype();
        }
        else
        {
            //output error 0
            err->flag(scan->this_token(), 0);

        }
    else
    {
    //identifier noT found error 0
            err->flag(scan->this_token(), 0);
    }

        return return_type;
    }
} //END SEMANTIC ANALYSIS: HANDLE IDENTIFIER IN AN EXPRESSION
*/
