/*
*
*    Created by: Hanna Zelis
*
*    Date: November 8th 2023
*/



#include <iostream>
#include <string>
#include <cctype>
#include <cmath>
#include <list>
#include <vector>

#include "symbol.h"
#include "token.h"
#include "error_handler.h"
#include "scanner.h"
#include "parser.h"
#include "id_table.h"
#include "id_table_entry.h"

using namespace std;

parser::parser(scanner* scan1, id_table* id_tab1, error_handler* err1)
{
   this->scan = scan1;
   this->err = err1;
   this->id_tab = id_tab1;   
}

// <prog> ::= program <ident> is <block> ;
void parser::prog()
{
   if (debugging) cout << "Parser: entering prog" << endl;

   token* predefined_func;
   token* argument;
   symbol* predefined_sym;
   id_table_entry* func_id;
   id_table_entry* param_id;


   /*
   //Int2Real
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("INT2REAL");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, 0, lille_type::type_real);

   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__int2real_arg__");
   param_id = new id_table_entry(argument,lille_type::type_integer,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id);


   //Real2Int
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("REAL2INT");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, 0, lille_type::type_integer);


   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__real2int_arg__");
   param_id = new id_table_entry(argument,lille_type::type_real,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id);


    //Int2string
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("INT2STRING");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, 0, lille_type::type_string); //???


   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__int2string_arg__");
   param_id = new id_table_entry(argument,lille_type::type_integer,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id);


   //String2Int
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("STRING2INT");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, 0, lille_type::type_integer); //???


   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__string2int_arg__");
   param_id = new id_table_entry(argument,lille_type::type_string,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id); 
   */
   
   
   scan->get_token();

   scan->must_be(symbol::program_sym);
   scan->must_be(symbol::identifier);

    //enter scope here

   scan->must_be(symbol::is_sym);
   block();
   scan->must_be(symbol::semicolon_sym);
   scan->must_be(symbol::end_of_program);

   //exit scope
	   
   if (debugging) cout << "Parser: exiting prog" << endl;


}

// <block> ::= { <declaration> }* begin <statement_list> end [ <ident> ]
void parser::block()
{
   if (debugging) cout << "Parser: entering block" << endl;

   while(scan->have(symbol::identifier) || scan->have(symbol::procedure_sym) || scan->have(symbol::function_sym))
      declaration();

   scan->must_be(symbol::begin_sym);
   statement_list();
   scan->must_be(symbol::end_sym);
   if(scan->have(symbol::identifier))
   {
      scan->must_be(symbol::identifier);
   }

   

   if (debugging) cout << "Parser: exiting block" << endl;
}

/* <declaration> ::= <ident_list> : [ constant ] <type>
*                                 [:=<number> | :=<string> | :=<bool>] ;
*                | procedure <ident> [ ( <param_list> ) ] is <block> ;
*                | function <ident> [(<param_list>)] return <type> is <block> ;
*/
void parser::declaration()
{
   if (debugging) cout << "Parser: entering declaration" << endl;


    int count = 0;
    bool comma_found = false;
    bool const_decl = false;
    id_table_entry* id;
    lille_kind knd;
    lille_type ty;
    symbol sym; 

    float r_const;
    string s_const;
    bool b_const;
    int i_const;

    token* block_name;

    vector<token*> list;

   if (scan->have(symbol::identifier))
   {

         cout << "PRE CORE DUMP 1" << endl;

      do
      {
         if (scan->have(symbol::identifier))
         {
            cout << "PRE CORE DUMP 2" << endl;
            scan->must_be(symbol::identifier);
            cout << "PRE CORE DUMP 3" << endl;
            if(scan->have(symbol::constant_sym))
            {
               cout << "PRE CORE DUMP 4" << endl;
               list.push_back(scan->this_token());
               cout << "PRE CORE DUMP 5" << endl;
               scan->must_be(symbol::constant_sym);
               cout << "PRE CORE DUMP 6" << endl;
               const_decl = true;
               cout << "PRE CORE DUMP 7" << endl;
               count++;
            }

            cout << "PRE CORE DUMP 8" << endl;

         }
         cout << "PRE CORE DUMP 9" << endl;
         comma_found = scan->have(symbol::comma_sym);
         cout << "PRE CORE DUMP 10" << endl;
         if (comma_found){
            cout << "PRE CORE DUMP 11" << endl;
            scan->must_be(symbol::comma_sym);
         }
         cout << "PRE CORE DUMP 12" << endl;

      } while (comma_found);

      cout << "PRE CORE DUMP 13" << endl;



   scan->must_be(symbol::colon_sym);
   cout << "PRE CORE DUMP 14" << endl;
   if(scan->have(symbol::constant_sym))
   {
      cout << "PRE CORE DUMP 15" << endl;
      const_decl = true;
      cout << "PRE CORE DUMP 16" << endl;
      knd = lille_kind(lille_kind::constant);
      cout << "PRE CORE DUMP 17" << endl;
      scan->must_be(symbol::constant_sym);
      cout << "PRE CORE DUMP 18" << endl;
   }

   else
   {
      cout << "PRE CORE DUMP 20" << endl;
      knd = lille_kind(lille_kind::variable);
      cout << "PRE CORE DUMP 21" << endl;
      ty = type(); //refer to type function
      cout << "PRE CORE DUMP 22" << endl;
   }

   cout << "PRE CORE DUMP 23" << endl;


   if(const_decl)
   {
      cout << "PRE CORE DUMP 24" << endl;
      scan->must_be(symbol::becomes_sym);
      cout << "PRE CORE DUMP 25" << endl;
      sym = scan->this_token()->get_symbol()->get_sym();
      cout << "PRE CORE DUMP 26" << endl;
      if (symbol::real_num)
      {
         cout << "PRE CORE DUMP 27" << endl;
         r_const = scan->this_token()->get_real_value();
         cout << "PRE CORE DUMP 28" << endl;
         if (!ty.is_type(lille_type::type_real)){
            cout << "PRE CORE DUMP 29" << endl;
            err->flag(scan->this_token(), 111);
         }

         cout << "PRE CORE DUMP 30" << endl;

      }


      else if (symbol::integer)
      {
         cout << "PRE CORE DUMP 32" << endl;
         r_const = scan->this_token()->get_integer_value();
         cout << "PRE CORE DUMP 33" << endl;
         if (!ty.is_type(lille_type::type_integer))
         {
            cout << "PRE CORE DUMP 34" << endl;
            err->flag(scan->this_token(), 111);
         }
         cout << "PRE CORE DUMP 35" << endl;
      }
      cout << "PRE CORE DUMP 36" << endl;
      scan->get_token();
      cout << "PRE CORE DUMP 37" << endl;
   }

   cout << "PRE CORE DUMP 38" << endl;

   vector<token*>::iterator ptr=list.begin();

   cout << "PRE CORE DUMP 39" << endl;

   while((ptr != list.end()) and (count >0))
   {
      cout << "PRE CORE DUMP 40" << endl;
      token* tok = *ptr;
      cout << "PRE CORE DUMP 41" << endl;
      id = id_tab->enter_id(tok, ty, knd, id_tab->scope(), 0, lille_type::type_unknown);
      cout << "PRE CORE DUMP 42" << endl;
      if(const_decl){
         cout << "PRE CORE DUMP 43" << endl;
         id->fix_const(i_const, r_const, s_const, b_const);
      }
      cout << "PRE CORE DUMP 44" << endl;
      //ptr=ptr->next;
      ++ptr;
      cout << "PRE CORE DUMP 45" << endl;
      count--;
      cout << "PRE CORE DUMP 46" << endl;
   }
   cout << "PRE CORE DUMP 47" << endl;
   } //end of the whole if statement for the variable declaration
   cout << "PRE CORE DUMP 48" << endl;
   



   if(scan->have(symbol::becomes_sym))  
   {
      cout << "PRE CORE DUMP 49" << endl;
      scan->must_be(symbol::becomes_sym);
         if(scan->have(symbol::integer_sym))
            scan->must_be(symbol::integer_sym);
         else if(scan->have(symbol::real_sym))
            scan->must_be(symbol::real_sym);
         else if(scan->have(symbol::string_sym))
            scan->must_be(symbol::string_sym);
         else if(scan->have(symbol::boolean_sym))
            scan->have(symbol::boolean_sym);
   }
   cout << "PRE CORE DUMP 50" << endl;
      scan->must_be(symbol::semicolon_sym);

      cout << "PRE CORE DUMP 51" << endl;
   

   if(scan->have(symbol::procedure_sym))
   {
      cout << "PRE CORE DUMP 52" << endl;
      scan->must_be(symbol::procedure_sym);
      cout << "PRE CORE DUMP 53" << endl;
      if (scan->have(symbol::identifier))
      {
         cout << "PRE CORE DUMP 54" << endl;
         id = id_tab->enter_id(scan->this_token(), lille_type::type_proc, lille_kind::unknown, id_tab->scope(), 0, lille_type::type_unknown);
         cout << "PRE CORE DUMP 55" << endl;
         //scan->must_be(symbol::identifier);
      }

      block_name = scan->this_token();

      id_tab->enter_scope();
     
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
         param_list();  //may put in id later, once editing param list
         scan->must_be(symbol::right_paren_sym);
      }

      //semantic analysis - procedure and fucntion
      scan->must_be(symbol::return_sym);
      if (scan->have(symbol::integer_sym))
      {
         id->fix_return_type(lille_type::type_integer);
         scan->must_be(symbol::integer_sym);
      }

      else if (scan->have(symbol::real_sym)) 
      {
         id->fix_return_type(lille_type::type_real);
         scan->must_be(symbol::real_sym);
      }

      else if (scan->have(symbol::string_sym)) 
      {
         id->fix_return_type(lille_type::type_string);
         scan->must_be(symbol::string_sym);
      }

      else if (scan->have(symbol::boolean_sym)) 
      {
         id->fix_return_type(lille_type::type_boolean);
         scan->must_be(symbol::boolean_sym);
      }

      else{
         err->flag(scan->this_token(), 108);    //type expected
      }
      
      scan->must_be(symbol::is_sym);
      block(); //will add parameters later if necessary
      scan->must_be(symbol::semicolon_sym);

      id_tab->exit_scope();
      /*current_offset = old_offset;

      CODE GEN STUFF

      if (return_count == 0)
         err->flag(scan->this_token(), 109);*/

      if (scan->have(symbol::identifier))
      {
         if (block_name->get_identifier_value() != scan->this_token()->get_identifier_value())
            err->flag(scan->this_token(), 107);

         scan->must_be(symbol::identifier);

      }

   }


   if(scan->have(symbol::function_sym))
   {
      scan->must_be(symbol::function_sym);
      if (scan->have(symbol::identifier))
      {
         id = id_tab->enter_id(scan->this_token(), lille_type::type_func, lille_kind::unknown, id_tab->scope(), 0, lille_type::type_unknown);
         //scan->must_be(symbol::identifier);
      }

      block_name = scan->this_token();

      id_tab->enter_scope();
     
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
         param_list();  //may put in id later, once editing param list
         scan->must_be(symbol::right_paren_sym);
      }

      //semantic analysis - procedure and fucntion
      scan->must_be(symbol::return_sym);
      if (scan->have(symbol::integer_sym))
      {
         id->fix_return_type(lille_type::type_integer);
         scan->must_be(symbol::integer_sym);
      }

      else if (scan->have(symbol::real_sym)) 
      {
         id->fix_return_type(lille_type::type_real);
         scan->must_be(symbol::real_sym);
      }

      else if (scan->have(symbol::string_sym)) 
      {
         id->fix_return_type(lille_type::type_string);
         scan->must_be(symbol::string_sym);
      }

      else if (scan->have(symbol::boolean_sym)) 
      {
         id->fix_return_type(lille_type::type_boolean);
         scan->must_be(symbol::boolean_sym);
      }

      else{
         err->flag(scan->this_token(), 108);    //type expected
      }
      
      scan->must_be(symbol::is_sym);
      block(); //will add parameters later if necessary
      scan->must_be(symbol::semicolon_sym);

      id_tab->exit_scope();
      /*current_offset = old_offset;

      CODE GEN STUFF

      if (return_count == 0)
         err->flag(scan->this_token(), 109);*/

      if (scan->have(symbol::identifier))
      {
         if (block_name->get_identifier_value() != scan->this_token()->get_identifier_value())
            err->flag(scan->this_token(), 107);

         scan->must_be(symbol::identifier);

      }

   }


/*
   if(scan->have(symbol::function_sym))
   {
      scan->must_be(symbol::function_sym);
      scan->must_be(symbol::identifier);

      type();    
 
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
         param_list();
         scan->must_be(symbol::right_paren_sym);
      }
      
      scan->must_be(symbol::return_sym);
      type();
      scan->must_be(symbol::is_sym);
      block();
      scan->must_be(symbol::semicolon_sym);     
   }
   */
      
   if (debugging) cout << "Parser: exiting declaration" << endl;
}

// <type> ::= integer | real | string | boolean
lille_type parser::type()
{
   lille_type return_type;

   if (debugging) cout << "Parser: entering type" << endl;
   
   if(scan->have(symbol::integer_sym))
   {
      scan->must_be(symbol::integer_sym);
      return_type = lille_type::type_integer;
   }
   else if(scan->have(symbol::real_sym))
   {
      scan->must_be(symbol::real_sym);
      return_type = lille_type::type_real;
   }
   else if(scan->have(symbol::string_sym))
   {
      scan->must_be(symbol::string_sym);
      return_type = lille_type::type_string;
   }
   else if(scan->have(symbol::boolean_sym))
   {
      scan->must_be(symbol::boolean_sym);
      return_type = lille_type::type_boolean;
   }

   return return_type;

   if (debugging) cout << "Parser: exiting type" << endl;
   


} //end of declaration function




// <param_list> ::= <param> { ; <param> }*
void parser::param_list()
{
   if (debugging) cout << "Parser: entering param_list" << endl;

   param();
   while(scan->have(symbol::semicolon_sym))
   {
      scan->must_be(symbol::semicolon_sym);
      param();
   }

  //semantic analysis
  
   // Initializing variables for parameter building
    int count = 0;
    lille_type ty;
    lille_kind knd;

    bool comma_found = false;
    bool const_decl = false;
    id_table_entry* id;

    symbol sym; 

    float r_const;
    string s_const;
    bool b_const;
    int i_const;

    token* block_name;

    vector<token*> list;

    // Loop to build a list of parameters
    /*while (scan->have(symbol::identifier)) {
        // Get the parameter type
        ty = type();
        // Determine the parameter kind (value or ref)
        if (scan->have(symbol::value_sym)) {
            scan->must_be(symbol::value_sym);
            knd = lille_kind::value_parameter;
        } else if (scan->have(symbol::ref_sym)) {
            scan->must_be(symbol::ref_sym);
            knd = lille_kind::ref_parameter;
        } else {
            knd = lille_kind::unknown;
        }

        // Creating parameter ID and adding it to the ID table
        id_table_entry* param_id = new id_table_entry(scan->this_token(), ty, knd, id_tab->scope(), current_offset, lille_type::type_unknown);
        id_tab->add_table_entry(param_id);
        id->add_param(param_id);
        
        count++;

        // Move to the next token if available
        scan->get_token();
        
        // Check if there are more parameters to process
        if (scan->have(symbol::comma_sym)) {
            scan->must_be(symbol::comma_sym);
        } else {
            break;
        }
    }*/

    // Perform additional operations if needed based on the created parameter list
    // …
    // …
    // …
    // …
    // …
    // …


    // Loop through the parameters to finalize their entries
    
    /*while ((ptr != NULL) && (count > 0)) {
        param_id = new id_table_entry(ptr->val, ty, knd, id_tab->scope(), 0, lille_type::type_unknown);
        id_tab->add_table_entry(param_id);
        id->add_param(param_id);
        count--;

        if (ptr->next != NULL) {
            ptr = ptr->next;
        }
    }*/

   vector<token*>::iterator ptr=list.begin();
   
   while((ptr != list.end()) and (count >0))
   {
      token* tok = *ptr;
      id = id_tab->enter_id(tok, ty, knd, id_tab->scope(), 0, lille_type::type_unknown);
      if(const_decl)
         id->fix_const(i_const, r_const, s_const, b_const);
      //ptr=ptr->next;
      ++ptr;
      count--;
   }
    

   if (debugging) cout << "Parser: entering param_list" << endl;
}

// <param> ::= <ident_list> : <param_kind> <type>
void parser::param()
{
   if (debugging) cout << "Parser: entering param" << endl;
   
   ident_list();
   scan->must_be(symbol::colon_sym);
   param_kind();
   type();

   if (debugging) cout << "Parser: exiting param" << endl;
}

// <ident_list> ::= <ident> { , <ident> }*
void parser::ident_list()
{
   if (debugging) cout << "Parser: entering ident_list" << endl;

   scan->must_be(symbol::identifier);
   while (scan->have(symbol::comma_sym))
   {
      scan->must_be(symbol::comma_sym);
      scan->must_be(symbol::identifier);
   }

   if (debugging) cout << "Parser: exiting ident_list" << endl;
}

// <param_kind> ::= value | ref 
void parser::param_kind()
{
   if (debugging) cout << "Parser: entering param_kind" << endl;

   if(scan->have(symbol::value_sym))
   {
      scan->must_be(symbol::value_sym);
   }
   else if(scan->have(symbol::ref_sym))
   {
      scan->must_be(symbol::ref_sym);
   }

   if (debugging) cout << "Parser: exiting param_kind" << endl;
}

// <statement_list> ::= <statement> ; { <statement> ; }*
void parser::statement_list()
{
   if (debugging) cout << "Parser: entering statement_list" << endl;

   statement();
   scan->must_be(symbol::semicolon_sym);
   while(scan->have(symbol::identifier) || scan->have(symbol::exit_sym) || scan->have(symbol::return_sym) || scan->have(symbol::read_sym) ||
         scan->have(symbol::write_sym) || scan->have(symbol::writeln_sym) || scan->have(symbol::if_sym) || scan->have(symbol::loop_sym) ||
         scan->have(symbol::for_sym) || scan->have(symbol::while_sym) || scan->have(symbol::null_sym))
   {
      statement();
      scan->must_be(symbol::semicolon_sym);
   }

   if (debugging) cout << "Parser: exiting statement_list" << endl;
}

/* <statement> ::= <simple_statement>
*             | <compound_statement>
*/
void parser::statement()
{
   if (debugging) cout << "Parser: entering statement" << endl;

   if(scan->have(symbol::if_sym) || scan->have(symbol::while_sym) ||
      scan->have(symbol::for_sym) || scan->have(symbol::loop_sym))
   {
      compound_statement();
   }
   else if(scan->have(symbol::identifier) || scan->have(symbol::exit_sym) || scan->have(symbol::return_sym) || scan->have(symbol::read_sym) ||
         scan->have(symbol::write_sym) || scan->have(symbol::writeln_sym) || scan->have(symbol::null_sym)) 
   {
      simple_statement();
   }

   if (debugging) cout << "Parser: exiting statement" << endl;
}

//FINISH

/* <simple_statement> ::= <ident> [ ( <expr> { , <expr> }* ) ]
*                     | <ident> := <expr>
*                     | exit [ when <expr> ]
*                     | return [ <expr> ]
*                     | read [ ( ] <ident> { , <ident> }* [ ) ]
*                     | write [ ( ] <expr> { , <expr> }* [ ) ]
*                     | writeln [ ( ] [ <expr> { , <expr> }* ] [ ) ]
*                     | null
*/
void parser::simple_statement()
{
   if (debugging) cout << "Parser: entering simple_statement" << endl;

   if(scan->have(symbol::identifier))
   {
      scan->must_be(symbol::identifier);
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
         expr();
         while(scan->have(symbol::comma_sym))
         {
            scan->must_be(symbol::comma_sym);
            expr();
         }
         scan->must_be(symbol::right_paren_sym);
      }

      else if(scan->have(symbol::becomes_sym))
      {
         scan->must_be(symbol::becomes_sym);
         expr();
      }
   }
   else if(scan->have(symbol::exit_sym))
   {
      scan->must_be(symbol::exit_sym);
      if(scan->have(symbol::when_sym))
      {
         scan->must_be(symbol::when_sym);
         expr();
      }
   }

   else if(scan->have(symbol::return_sym))
   {
      scan->must_be(symbol::return_sym);
      if(scan->have(symbol::identifier) || scan->have(symbol::integer) || scan->have(symbol::real_sym) ||
         scan->have(symbol::strng) || scan->have(symbol::boolean_sym))
      {
         expr();
      }
   }

   else if(scan->have(symbol::read_sym))
   {
      scan->must_be(symbol::read_sym);
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
      }
      scan->must_be(symbol::identifier);
      while(scan->have(symbol::comma_sym))
      {
         scan->must_be(symbol::comma_sym);
         scan->must_be(symbol::identifier);
      }
      if(scan->have(symbol::right_paren_sym))
      {
         scan->must_be(symbol::right_paren_sym);
      }
   }
   else if(scan->have(symbol::write_sym))
   {
      scan->must_be(symbol::write_sym);
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
      }
      expr();
      while(scan->have(symbol::comma_sym))
      {
         scan->must_be(symbol::comma_sym);
         expr();
      }
      if(scan->have(symbol::right_paren_sym))
      {
         scan->must_be(symbol::right_paren_sym);
      }
   }

   else if(scan->have(symbol::writeln_sym))
   {
      scan->must_be(symbol::writeln_sym);
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
      }

      if(scan->have(symbol::identifier) || scan->have(symbol::integer) || scan->have(symbol::real_sym) ||
         scan->have(symbol::not_sym) || scan->have(symbol::boolean_sym) || scan->have(symbol::strng) || scan->have(symbol::odd_sym))
      {
         expr();
         while(scan->have(symbol::comma_sym))
         {
            scan->must_be(symbol::comma_sym);
            expr();
         }
      }
    
      if(scan->have(symbol::right_paren_sym))
      {
         scan->must_be(symbol::right_paren_sym);
      }
   }

   else if(scan->have(symbol::null_sym))
   {
      scan->must_be(symbol::null_sym);
   }
         
   if (debugging) cout << "Parser: exiting simple_statement" << endl;
}

/* <compound_statement> ::= <if_statement>
*                       | <loop_statement>
*                       | <for_statement>
*                       | <while_statement>
*/
void parser::compound_statement()
{
   if (debugging) cout << "Parser: entering compoun_statement" << endl;

   if(scan->have(symbol::if_sym))
   {
      if_statement();
   }
   else if(scan->have(symbol::loop_sym))
   {
      loop_statement();
   }
   else if(scan->have(symbol::for_sym))
   {
      for_statement();
   }
   else if(scan->have(symbol::while_sym))
   {
      while_statement();
   }

   if (debugging) cout << "Parser: exiting compound_statement" << endl;
}

/* <if_statement> ::= if <expr> then <statement_list>
*                 { elsif <expr> then <statement_list> }*
*                 [ else <statement_list> ]
*                 end if
*/
void parser::if_statement()
{
   if (debugging) cout << "Parser: entering if_statement" << endl;

   scan->must_be(symbol::if_sym);
   expr();
   scan->must_be(symbol::then_sym);
   statement_list();
   
   while(scan->have(symbol::elsif_sym))
   {
      scan->must_be(symbol::elsif_sym);
      expr();
      scan->must_be(symbol::then_sym);
      statement_list();
   }
   
   if(scan->have(symbol::else_sym))
   {
      scan->must_be(symbol::else_sym);
      statement_list();
   }
  
   scan->must_be(symbol::end_sym);
   scan->must_be(symbol::if_sym);

   if (debugging) cout << "Parser: exiting if_statement" << endl;

}

// <while_statement> ::= while <expr> <loop_statement>
void parser::while_statement()
{
   if (debugging) cout << "Parser: entering while_statement" << endl;

   scan->must_be(symbol::while_sym);
   expr();
   loop_statement();

   if (debugging) cout << "Parser: exiting while_statement" << endl;
}

// <for_statement> ::= for <ident> in [ reverse ] <range> <loop_statement>
void parser::for_statement()
{
   if (debugging) cout << "Parser: entering for_statement" << endl;

   scan->must_be(symbol::for_sym);
   scan->must_be(symbol::identifier);
   scan->must_be(symbol::in_sym);
   if(scan->have(symbol::reverse_sym))
   {
      scan->must_be(symbol::reverse_sym);
   }
   
   range();
   loop_statement(); 
  
   if (debugging) cout << "Parser: exiting for_statement" << endl;
}

// <loop_statement> ::= loop <statement_list> end loop
void parser::loop_statement()
{
   if (debugging) cout << "Parser: entering loop_statement" << endl;

   scan->must_be(symbol::loop_sym);
   statement_list();
   scan->must_be(symbol::end_sym);
   scan->must_be(symbol::loop_sym);

   if (debugging) cout << "Parser: exiting loop_statement" << endl;
}

// <range> ::= <simple_expr> .. <simple_expr>
void parser::range()
{
   if (debugging) cout << "Parser: entering range" << endl;

   simple_expr();
   scan->must_be(symbol::range_sym);
   simple_expr();

   if (debugging) cout << "Parser: exiting range" << endl;
}

//FINISH
/* <expr> ::= <simple_expr> [ <relop> <simple_expr> ]
*         | <simple_expr> in <range>
*/
void parser::expr()
{
   if (debugging) cout << "Parser: entering expr" << endl;

   simple_expr();
   if(scan->have(symbol::greater_than_sym) || scan->have(symbol::less_than_sym) || scan->have(symbol::equals_sym) ||
      scan->have(symbol::less_or_equal_sym) || scan->have(symbol::greater_or_equal_sym) || scan->have(symbol::not_equals_sym))
   {
      relop();
      simple_expr();
   }
   else if(scan->have(symbol::in_sym))
   {
      scan->must_be(symbol::in_sym);
      range();
   }

   if (debugging) cout << "Parser: exiting expr" << endl;
}

// <relop> ::= > | < | = | <> | <= | >=
void parser::relop()
{
   if (debugging) cout << "Parser: entering relop" << endl;

   if(scan->have(symbol::greater_than_sym) || scan->have(symbol::less_than_sym) || scan->have(symbol::equals_sym) ||
      scan->have(symbol::not_equals_sym) || scan->have(symbol::less_or_equal_sym) || scan->have(symbol::greater_or_equal_sym))
   {
      scan->get_token();
   }
   else
   {
      err->flag(scan->this_token(), 105);
   }

   if (debugging) cout << "Parser: exiting relop" << endl;
}

// <simple_expr> ::= <expr2> { <stringop> <expr2> }*
void parser::simple_expr()
{
   if (debugging) cout << "Parser: entering simple_expr" << endl;

   expr2();
   while(scan->have(symbol::ampersand_sym))
   {
      scan->must_be(symbol::ampersand_sym);
      expr2();
   }

   if (debugging) cout << "Parser: exiting simple_expr" << endl;
}

// <expr2> ::= <term> { { <addop> | or } <term> }*
void parser::expr2()
{
   if (debugging) cout << "Parser: entering expr2" << endl;

   term();
 
   while(scan->have(symbol::plus_sym) || scan->have(symbol::minus_sym) || scan->have(symbol::or_sym))
   {
      if(scan->have(symbol::plus_sym))
      {
         scan->must_be(symbol::plus_sym);
      }
      else if(scan->have(symbol::minus_sym))
      {
         scan->must_be(symbol::minus_sym);   
      }
      else if(scan->have(symbol::or_sym))
      {
         scan->must_be(symbol::or_sym);   
      }
      term();
   }

   if (debugging) cout << "Parser: exiting expr2" << endl;
}

// <term> ::= <factor> { { <multop> | and } <factor> }*
void parser::term()
{
   if (debugging) cout << "Parser: entering term" << endl;

   factor();

   while(scan->have(symbol::asterisk_sym) || scan->have(symbol::slash_sym) || scan->have(symbol::and_sym))
   {
      if(scan->have(symbol::asterisk_sym))
      {
         scan->must_be(symbol::asterisk_sym);
      }
      else if(scan->have(symbol::slash_sym))
      {
         scan->must_be(symbol::slash_sym);
      }
      else if(scan->have(symbol::and_sym))
      {
         scan->must_be(symbol::and_sym);
      }
   }   

   factor();

   if (debugging) cout << "Parser: exiting term" << endl;
}

/* <factor> ::= <primary> [ ** <primary> ]
*           | [ <addop> ] <primary>
*/
void parser::factor()
{
   if (debugging) cout << "Parser: entering factor" << endl;

   primary();
   if(scan->have(symbol::power_sym))
   {
      scan->must_be(symbol::power_sym);
      primary();
   }
   else if(scan->have(symbol::plus_sym) || scan->have(symbol::minus_sym))
   {
      if(scan->have(symbol::plus_sym))
      {
         scan->must_be(symbol::plus_sym);
      }
      else if(scan->have(symbol::minus_sym))
      {
         scan->must_be(symbol::minus_sym);
      }
      primary();
   }

   if (debugging) cout << "Parser: exiting factor" << endl;
}

/* <primary> ::= not <expr>
*            | odd <expr>
*            | ( <simple_expr> )
*            | <ident> [ ( <expr>{ , <expr> }* ) ]
*            | <number>
*            | <string>
*            | <bool>
*/
void parser::primary()
{
   if (debugging) cout << "Parser: entering primary" << endl;

   if(scan->have(symbol::not_sym))
   {
      scan->must_be(symbol::not_sym);
      expr();
   }
   else if(scan->have(symbol::odd_sym))
   {
      scan->must_be(symbol::odd_sym);
      expr();
   }
   else if(scan->have(symbol::left_paren_sym))
   {
      scan->must_be(symbol::left_paren_sym);
      simple_expr();
      scan->must_be(symbol::right_paren_sym);
   }
   else if(scan->have(symbol::identifier))
   {
      scan->must_be(symbol::identifier);
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
         expr();
         while(scan->have(symbol::comma_sym))
         {
            scan->must_be(symbol::comma_sym);
            expr();
         }
         scan->must_be(symbol::right_paren_sym);
      }
   }
   else if(scan->have(symbol::integer))
      scan->must_be(symbol::integer);
   else if(scan->have(symbol::real_sym))
      scan->must_be(symbol::real_sym);
   else if(scan->have(symbol::strng))
      scan->must_be(symbol::strng);
   else if(scan->have(symbol::boolean_sym))
      scan->must_be(symbol::boolean_sym);

   if (debugging) cout << "Parser: exiting primary" << endl;
}


/*
//SEMANTIC ANALYSIS: HANDLING PREDEFINED FUNCTIONS - *insert what it does here*
void parser::predefined_routines()
{


   token* predefined_func;
   token* argument;
   symbol* predefined_sym;
   id_table_entry* func_id;
   id_table_entry* param_id;


   //Int2Real
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("INT2REAL");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, code->current_code_ptr(), lille_type::type_real);


   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__int2real_arg__");
   param_id = new id_table_entry(argument,lille_type::type_integer,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id);


   //Real2Int
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("REAL2INT");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, code->current_code_ptr(), lille_type::type_integer);


   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__real2int_arg__");
   param_id = new id_table_entry(argument,lille_type::type_real,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id);


    //Int2string
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("INT2STRING");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, code->current_code_ptr(), lille_type::type_string); //???


   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__int2string_arg__");
   param_id = new id_table_entry(argument,lille_type::type_integer,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id);


   //String2Int
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("STRING2INT");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, code->current_code_ptr(), lille_type::type_integer); //???


   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__string2int_arg__");
   param_id = new id_table_entry(argument,lille_type::type_string,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id);

} //END OF SEMANTIC ANALYSIS: HANDLING PREDEFINED FUNCTIONS
*/




/*
//SEMANTIC ANALAYSIS: VARIABLE DECLARATION - *insert what it does here*
void parser::variable_declaration()
{
    int count = 0;
    bool comma_found = false;
    bool const_decl = false;
    id_table_entry* id;
    lille_kind knd;
    symbol sym; 
    
    if (scan -> have(symbol::identifier)) { // variable or constant declaration
        do {
            if (scan -> have(symbol::identifier)) {
                ident_list(); //added here
                scan->get_token();
                count++;
            }
            comma_found = scan->have(symbol::comma_sym);
            if (comma_found)
                scan->must_be(symbol::comma_sym);
        } while (comma_found);
        
        scan->must_be(symbol::colon_sym);
        
        if (scan->have(symbol::constant_sym)) {
            const_decl = true;
            knd = lille_kind(lille_kind::constant);
            scan->must_be(symbol::constant_sym);
        } else {
            knd = lille_kind(lille_kind::variable);
        }
        
        ty = type(fsys);
        
        if (const_decl) {
            scan->must_be(symbol::becomes_sym);
            sym = scan->this_token()->get_symbol()->get_sym();
            switch (sym) {
                case symbol::real_num:
                    r_const = scan->this_token()->get_real_value();
                    if (!ty.is_type(lille_type::type_real))
                        err->flag(scan->this_token(), 111); // Const expr does not match type declaration.
                    break;
                case symbol::integer:
                    r_const = scan->this_token()->get_real_value();
                    if (!ty.is_type(lille_type::type_integer))
                        err->flag(scan->this_token(), 111); // Const expr does not match type declaration.
                    break;
                // add other cases as needed
            }
            scan->get_token();
        }    
        ptr = list;
        
        while ((ptr != NULL) and (count > 0)) {
            id = id_tab->enter_id(ptr->val, ty, knd, id_tab->scope(), current_offset, lille_type::type_unknown);
            
            if (const_decl)
                id->fix_const(i_const, r_const, s_const, b_const); // **** fix constant        
            ptr = ptr->next;
            count--;
        }
    }

} //END OF SEMANTIC ANALYSIS: VARIABLE DECLARATION





//SEMANTIC ANALYSIS: PROCEDURES AND FUNCTIONS - *insert what it does here* - declaration
void parser::procedures_and_functions() 
{
    id_table_entry* id;
    if (scan->have(symbol::function_sym)) {
        scan->must_be(symbol::function_sym);
        
        if (scan->have(symbol::identifier))
            id_table_entry* id = id_tab->enter_id(scan->this_token(), lille_type::type_func, lille_kind::unknown, id_tab->scope(), code->current_code_ptr(), lille_type::type_unknown);
            // Need to fix the return_type later once it is known.
        
        block_name = scan->this_token();
        scan->must_be(symbol::identifier);
        id_tab->enter_scope();
        
        if (scan->have(symbol::left_paren_sym)) {
            scan->must_be(symbol::left_paren_sym);
            param_list(fsys + symbol::right_paren_sym, id);
            scan->must_be(symbol::right_paren_sym);
        }
        
        scan->must_be(symbol::return_sym);
        
        if (scan->have(symbol::integer_sym)) {
            id->fix_return_type(lille_type::type_integer);
            scan->must_be(symbol::integer_sym);
        } else if (scan->have(symbol::real_sym)) {
            id->fix_return_type(lille_type::type_real);
            scan->must_be(symbol::real_sym);
        } else if (scan->have(symbol::string_sym)) {
            id->fix_return_type(lille_type::type_string);
            scan->must_be(symbol::string_sym);
        } else if (scan->have(symbol::procedure_sym)) {
            id->fix_return_type(lille_type::type_proc);
            scan->must_be(symbol::procedure_sym);
        } else if (scan->have(symbol::function_sym)) {
            id->fix_return_type(lille_type::type_func);
            scan->must_be(symbol::function_sym); 
        } else {
            err->flag(scan->this_token(), 108); // type expected.
        }
        
        scan->must_be(symbol::is_sym);
        block(fsys + symbol::semicolon_sym + symbol::identifier, block_name, return_count);
        id_tab->exit_scope();
        current_offset = old_offset;
        
        if (return_count == 0)
            err->flag(scan->this_token(), 109); // Functions must have at least 1 return statement.
        
        if (scan->have(symbol::identifier)) {
            if (block_name->get_identifier_value() != scan->this_token()->get_identifier_value())
                err->flag(scan->this_token(), 107); // Identifier must match name of the block.
            scan->must_be(symbol::identifier);
        }
    }

} //END OF SEMANTIC ANALYSIS: PROCEDURES AND FUNCTIONS 





//SEMANTIC ANALAYSIS: ASSIGNMENTS - *insert what it does here* - declaration
void parser::assignments_semantic_analysis()
{
    switch (scan->this_token()->get_symbol()->get_sym())
    {
        case symbol::identifier:
            token* tok = scan->this_token();
            id_table_entry* id_info = id_tab->lookup(tok);
            scan->must_be(symbol::identifier);

            if (scan->have(symbol::left_paren_sym))
            {
                // Better be a procedure!
                scan->must_be(symbol::left_paren_sym);

                if (!id_info->tipe().is_type(lille_type::type_proc))
                    err->flag(tok, 90);

                // Identifier must be a procedure name in this context.
                ident_list(fsys + symbol::right_paren_sym, id_info);
                scan->must_be(symbol::right_paren_sym);
            }
            else if (scan->have(symbol::becomes_sym))
            {
                // It's an assignment…
                if (!(id_info->kind().is_kind(lille_kind::variable) or id_info->kind().is_kind(lille_kind::ref_param)))
                    err->flag(tok, 85);

                // Identifier is not assignable. Must be a variable or reference parameter.
                scan->must_be(symbol::becomes_sym);

                if (expr_first_symbols.member(scan->this_token()->get_symbol()->get_sym()))
                {
                    lille_type exp_ty = expr(fsys);

                    // check LHS and RHS have matching types
                    if (!id_info->tipe().is_equal(exp_ty))
                    {
                        err->flag(scan->this_token(), 93);
                        // LHS and RHS of assignment are not type compatible.
                    }

                    if ((id_info->kind().is_kind(lille_kind::ref_param)) or (id_info->kind().is_kind(lille_kind::variable)))
                        trace_write(id_info, true);
                    else
                        err->flag(scan->this_token(), 92);
                        // String or expression expected.
                }
                else
                {
                    err->flag(tok, 91);
                    // Identifier illegal in this context.
                }
                break;
            }
    }
} //END OF SEMANTIC ANALYSIS: ASSIGNMENTS
*/



/*
//SEMANTIC ANALYSIS: HANDLE IDENTIFIER IN AN EXPRESSION
void parser::handle_identifier_in_expr()
{
    lille_kind knd*;
    case symbol::identifier:
        tok = scan->this_token();
        id = id_tab->lookup(tok);
        return_type = id->tipe();
        knd = id->kind();

    if(symbol != nullptr)
    {
                //different kinds of identifiers
                if (symbol->isVariable())
                {
                    // Handle variable
            variable* variable = static_cast<variable*>(symbol);
            return variable->getType();

                } 
    else if(symbol->isFunction()) 
    {
                    // Handle function
                    function* function = static_cast<Function*>(symbol);
            return function->getType();
                } 
    else if(symbol->isconstant())
    {
                constant* constant = static_cast<constant*>(symbol);
            return constant->gettype();
                }
        else if(symbol->isparameter())
        {
            parameter* parameter = static_cast<parameter*>(symbol);
            return parameter->gettype();
        }
        else
        {
            //output error 0
            err->flag(scan->this_token(), 0);

        }
    else
    {
    //identifier noT found error 0
            err->flag(scan->this_token(), 0);
    }

        return return_type;
    }
} //END SEMANTIC ANALYSIS: HANDLE IDENTIFIER IN AN EXPRESSION
*/
