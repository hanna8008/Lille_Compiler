/*
* parser.h
*
*  Created on: November 10, 2023
*      Author: Hanna Zelis
*/


#ifndef PARSER_H_
#define PARSER_H_


#include <iostream>
#include <fstream>
#include <string>


#include "symbol.h"
#include "token.h"
#include "error_handler.h"
#include "scanner.h"


using namespace std;


class parser {
private:


    
    
    //no destructor bc the pointers are non-owning

public:
    bool debugging {false};

    id_table* id_tab;
    scanner* scan;     //pointer to scanner object
    error_handler* err;     //pointer to error_handler object
    //code* code;         //we added this for semantic analysis

    parser();   //constructor with no parameter
    parser(scanner* scan1, id_table* id_tab1, error_handler* err1);     //constructor with parameters (id_table* id_tab)
    //void parser(scanner* scan);     //constructor 

    void prog();
    void block();
    void declaration();
    lille_type type();
    void param_list();
    void param();
    void ident_list();
    void param_kind();
    void statement_list(); 
    void statement(); 
    lille_type simple_statement();
    void compound_statement();
    void if_statement();
    void while_statement();
    void for_statement();
    void loop_statement();
    void range();
    lille_type expr();
    void relop();
    lille_type simple_expr();
    void stringop();
    lille_type expr2(); 
    void addop();
    lille_type term(); 
    void multop();
    lille_type factor();
    lille_type primary(); 

    void bool_function();
    //void string();
    //void ident();
    //void ident2();
    //void number();
    //void digit_seq();
    //void exp();
    //void pragma();
    //void pragma_name();

    //error recvoery - scheme #1
    //void syntax();
    //void must_be(symbol::symbol_type s);


    //SEMANTIC ANALAYSIS PARSER declarations
    //void predefined_routines();
    //void variable_declaration();
    //void procedures_and_functions();
    //void assignments_semantic_analysis();
    //void handle_identifier_in_expr()
    //void current_code_ptr();

};


#endif /* PARSER_H_ */