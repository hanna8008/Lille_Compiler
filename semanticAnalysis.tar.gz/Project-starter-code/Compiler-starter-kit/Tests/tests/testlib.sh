#!/bin/bash

# ANSI color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
WHITE='\033[0m'

# Compiler-related constants
MY_COMPILER='../../../compiler'
HIS_COMPILER='../../../../compiler'
