/*
*
*    Created by: Kolt Byers
*    Date: November 8th 2023
*/



#include <iostream>
#include <string>
#include <cctype>
#include <cmath>

#include "symbol.h"
#include "token.h"
#include "error_handler.h"
#include "scanner.h"
#include "parser.h"
#include "id_table.h"

using namespace std;

parser::parser(scanner* scan, id_table* id_tab, error_handler* err) : scan(scan), err(err)
{
   this->scan = scan;
   this->err = err;
//   this->id_tab = id_tab;   
}

// <prog> ::= program <ident> is <block> ;
void parser::prog()
{
   if (debugging) cout << "Parser: entering prog" << endl;
   
   scan->get_token();

   scan->must_be(symbol::program_sym);
   scan->must_be(symbol::identifier);
   scan->must_be(symbol::is_sym);
   block();
   scan->must_be(symbol::semicolon_sym);
   scan->must_be(symbol::end_of_program);
	   
   if (debugging) cout << "Parser: exiting prog" << endl;


}

// <block> ::= { <declaration> }* begin <statement_list> end [ <ident> ]
void parser::block()
{
   if (debugging) cout << "Parser: entering block" << endl;

   //id_tab->enter_scope();

   while(scan->have(symbol::identifier) || scan->have(symbol::procedure_sym) || scan->have(symbol::function_sym))
      declaration();

   scan->must_be(symbol::begin_sym);
   statement_list();
   scan->must_be(symbol::end_sym);
   if(scan->have(symbol::identifier))
   {
      scan->must_be(symbol::identifier);
   }

   //id_tab->exit_scope();

   if (debugging) cout << "Parser: exiting block" << endl;
}

/* <declaration> ::= <ident_list> : [ constant ] <type>
*                                 [:=<number> | :=<string> | :=<bool>] ;
*                | procedure <ident> [ ( <param_list> ) ] is <block> ;
*                | function <ident> [(<param_list>)] return <type> is <block> ;
*/
void parser::declaration()
{
   if (debugging) cout << "Parser: entering declaration" << endl;

   if(scan->have(symbol::identifier))
   {
      ident_list();
      scan->must_be(symbol::colon_sym);
      if(scan->have(symbol::constant_sym))
      {
         scan->must_be(symbol::constant_sym);
         
     //    id_table_entry* new_entry = id_tab->enter_id(scan->this_token());
     //    new_entry->fix_const();
      }
      else
      {
         type();
      //   id_table_entry* new_entry = id_tab->enter_id(scan->this_token());
      }

      if(scan->have(symbol::becomes_sym))  
      {
         scan->must_be(symbol::becomes_sym);
    
         if(scan->have(symbol::integer_sym))
            scan->must_be(symbol::integer_sym);
         else if(scan->have(symbol::real_sym))
            scan->must_be(symbol::real_sym);
         else if(scan->have(symbol::string_sym))
            scan->must_be(symbol::string_sym);
         else if(scan->have(symbol::boolean_sym))
            scan->have(symbol::boolean_sym);
      }
   
      scan->must_be(symbol::semicolon_sym);
   }

   if(scan->have(symbol::procedure_sym))
   {
      scan->must_be(symbol::procedure_sym);
      scan->must_be(symbol::identifier);

      //id_table_entry* new_entry = id_tab->enter_id(scan->this_token());
      //new_entry->fix_return_type(lille_type::type_proc); 
     
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
         param_list();
         scan->must_be(symbol::right_paren_sym);
      }
      
      scan->must_be(symbol::is_sym);
      block();
      scan->must_be(symbol::semicolon_sym);
   }

   if(scan->have(symbol::function_sym))
   {
      scan->must_be(symbol::function_sym);
      scan->must_be(symbol::identifier);

      //id_table_entry* new_entry = id_tab->enter_id(scan->this_token());
      type();
      //new_entry->fix_return_type(lille_type::type_func);     
 
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
         param_list();
         scan->must_be(symbol::right_paren_sym);
      }
      
      scan->must_be(symbol::return_sym);
      type();
      scan->must_be(symbol::is_sym);
      block();
      scan->must_be(symbol::semicolon_sym);     
   }
      
   if (debugging) cout << "Parser: exiting declaration" << endl;
}

// <type> ::= integer | real | string | boolean
void parser::type()
{
   if (debugging) cout << "Parser: entering type" << endl;
   
   if(scan->have(symbol::integer_sym))
   {
      scan->must_be(symbol::integer_sym);
   }
   else if(scan->have(symbol::real_sym))
   {
      scan->must_be(symbol::real_sym);
   }
   else if(scan->have(symbol::string_sym))
   {
      scan->must_be(symbol::string_sym);
   }
   else if(scan->have(symbol::boolean_sym))
   {
      scan->must_be(symbol::boolean_sym);
   }

   if (debugging) cout << "Parser: exiting type" << endl;
}

// <param_list> ::= <param> { ; <param> }*
void parser::param_list()
{
   if (debugging) cout << "Parser: entering param_list" << endl;

   param();
   while(scan->have(symbol::semicolon_sym))
   {
      scan->must_be(symbol::semicolon_sym);
      param();
   }

   if (debugging) cout << "Parser: entering param_list" << endl;
}

// <param> ::= <ident_list> : <param_kind> <type>
void parser::param()
{
   if (debugging) cout << "Parser: entering param" << endl;
   
   ident_list();
   scan->must_be(symbol::colon_sym);
   param_kind();
   type();

   if (debugging) cout << "Parser: exiting param" << endl;
}

// <ident_list> ::= <ident> { , <ident> }*
void parser::ident_list()
{
   if (debugging) cout << "Parser: entering ident_list" << endl;

   scan->must_be(symbol::identifier);
   while (scan->have(symbol::comma_sym))
   {
      scan->must_be(symbol::comma_sym);
      scan->must_be(symbol::identifier);
   }

   if (debugging) cout << "Parser: exiting ident_list" << endl;
}

// <param_kind> ::= value | ref 
void parser::param_kind()
{
   if (debugging) cout << "Parser: entering param_kind" << endl;

   if(scan->have(symbol::value_sym))
   {
      scan->must_be(symbol::value_sym);
   }
   else if(scan->have(symbol::ref_sym))
   {
      scan->must_be(symbol::ref_sym);
   }

   if (debugging) cout << "Parser: exiting param_kind" << endl;
}

// <statement_list> ::= <statement> ; { <statement> ; }*
void parser::statement_list()
{
   if (debugging) cout << "Parser: entering statement_list" << endl;

   statement();
   scan->must_be(symbol::semicolon_sym);
   while(scan->have(symbol::identifier) || scan->have(symbol::exit_sym) || scan->have(symbol::return_sym) || scan->have(symbol::read_sym) ||
         scan->have(symbol::write_sym) || scan->have(symbol::writeln_sym) || scan->have(symbol::if_sym) || scan->have(symbol::loop_sym) ||
         scan->have(symbol::for_sym) || scan->have(symbol::while_sym) || scan->have(symbol::null_sym))
   {
      statement();
      scan->must_be(symbol::semicolon_sym);
   }

   if (debugging) cout << "Parser: exiting statement_list" << endl;
}

/* <statement> ::= <simple_statement>
*             | <compound_statement>
*/
void parser::statement()
{
   if (debugging) cout << "Parser: entering statement" << endl;

   if(scan->have(symbol::if_sym) || scan->have(symbol::while_sym) ||
      scan->have(symbol::for_sym) || scan->have(symbol::loop_sym))
   {
      compound_statement();
   }
   else if(scan->have(symbol::identifier) || scan->have(symbol::exit_sym) || scan->have(symbol::return_sym) || scan->have(symbol::read_sym) ||
         scan->have(symbol::write_sym) || scan->have(symbol::writeln_sym) || scan->have(symbol::null_sym)) 
   {
      simple_statement();
   }

   if (debugging) cout << "Parser: exiting statement" << endl;
}

//FINISH

/* <simple_statement> ::= <ident> [ ( <expr> { , <expr> }* ) ]
*                     | <ident> := <expr>
*                     | exit [ when <expr> ]
*                     | return [ <expr> ]
*                     | read [ ( ] <ident> { , <ident> }* [ ) ]
*                     | write [ ( ] <expr> { , <expr> }* [ ) ]
*                     | writeln [ ( ] [ <expr> { , <expr> }* ] [ ) ]
*                     | null
*/
void parser::simple_statement()
{
   if (debugging) cout << "Parser: entering simple_statement" << endl;

   if(scan->have(symbol::identifier))
   {
      scan->must_be(symbol::identifier);
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
         expr();
         while(scan->have(symbol::comma_sym))
         {
            scan->must_be(symbol::comma_sym);
            expr();
         }
         scan->must_be(symbol::right_paren_sym);
      }

      else if(scan->have(symbol::becomes_sym))
      {
         scan->must_be(symbol::becomes_sym);
         expr();
      }
   }
   else if(scan->have(symbol::exit_sym))
   {
      scan->must_be(symbol::exit_sym);
      if(scan->have(symbol::when_sym))
      {
         scan->must_be(symbol::when_sym);
         expr();
      }
   }

   else if(scan->have(symbol::return_sym))
   {
      scan->must_be(symbol::return_sym);
      if(scan->have(symbol::identifier) || scan->have(symbol::integer) || scan->have(symbol::real_sym) ||
         scan->have(symbol::strng) || scan->have(symbol::boolean_sym))
      {
         expr();
      }
   }

   else if(scan->have(symbol::read_sym))
   {
      scan->must_be(symbol::read_sym);
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
      }
      scan->must_be(symbol::identifier);
      while(scan->have(symbol::comma_sym))
      {
         scan->must_be(symbol::comma_sym);
         scan->must_be(symbol::identifier);
      }
      if(scan->have(symbol::right_paren_sym))
      {
         scan->must_be(symbol::right_paren_sym);
      }
   }
   else if(scan->have(symbol::write_sym))
   {
      scan->must_be(symbol::write_sym);
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
      }
      expr();
      while(scan->have(symbol::comma_sym))
      {
         scan->must_be(symbol::comma_sym);
         expr();
      }
      if(scan->have(symbol::right_paren_sym))
      {
         scan->must_be(symbol::right_paren_sym);
      }
   }

   else if(scan->have(symbol::writeln_sym))
   {
      scan->must_be(symbol::writeln_sym);
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
      }

      if(scan->have(symbol::identifier) || scan->have(symbol::integer) || scan->have(symbol::real_sym) ||
         scan->have(symbol::not_sym) || scan->have(symbol::boolean_sym) || scan->have(symbol::strng) || scan->have(symbol::odd_sym))
      {
         expr();
         while(scan->have(symbol::comma_sym))
         {
            scan->must_be(symbol::comma_sym);
            expr();
         }
      }
    
      if(scan->have(symbol::right_paren_sym))
      {
         scan->must_be(symbol::right_paren_sym);
      }
   }

   else if(scan->have(symbol::null_sym))
   {
      scan->must_be(symbol::null_sym);
   }
         
   if (debugging) cout << "Parser: exiting simple_statement" << endl;
}

/* <compound_statement> ::= <if_statement>
*                       | <loop_statement>
*                       | <for_statement>
*                       | <while_statement>
*/
void parser::compound_statement()
{
   if (debugging) cout << "Parser: entering compoun_statement" << endl;

   if(scan->have(symbol::if_sym))
   {
      if_statement();
   }
   else if(scan->have(symbol::loop_sym))
   {
      loop_statement();
   }
   else if(scan->have(symbol::for_sym))
   {
      for_statement();
   }
   else if(scan->have(symbol::while_sym))
   {
      while_statement();
   }

   if (debugging) cout << "Parser: exiting compound_statement" << endl;
}

/* <if_statement> ::= if <expr> then <statement_list>
*                 { elsif <expr> then <statement_list> }*
*                 [ else <statement_list> ]
*                 end if
*/
void parser::if_statement()
{
   if (debugging) cout << "Parser: entering if_statement" << endl;

   scan->must_be(symbol::if_sym);
   expr();
   scan->must_be(symbol::then_sym);
   statement_list();
   
   while(scan->have(symbol::elsif_sym))
   {
      scan->must_be(symbol::elsif_sym);
      expr();
      scan->must_be(symbol::then_sym);
      statement_list();
   }
   
   if(scan->have(symbol::else_sym))
   {
      scan->must_be(symbol::else_sym);
      statement_list();
   }
  
   scan->must_be(symbol::end_sym);
   scan->must_be(symbol::if_sym);

   if (debugging) cout << "Parser: exiting if_statement" << endl;

}

// <while_statement> ::= while <expr> <loop_statement>
void parser::while_statement()
{
   if (debugging) cout << "Parser: entering while_statement" << endl;

   scan->must_be(symbol::while_sym);
   expr();
   loop_statement();

   if (debugging) cout << "Parser: exiting while_statement" << endl;
}

// <for_statement> ::= for <ident> in [ reverse ] <range> <loop_statement>
void parser::for_statement()
{
   if (debugging) cout << "Parser: entering for_statement" << endl;

   scan->must_be(symbol::for_sym);
   scan->must_be(symbol::identifier);
   scan->must_be(symbol::in_sym);
   if(scan->have(symbol::reverse_sym))
   {
      scan->must_be(symbol::reverse_sym);
   }
   
   range();
   loop_statement(); 
  
   if (debugging) cout << "Parser: exiting for_statement" << endl;
}

// <loop_statement> ::= loop <statement_list> end loop
void parser::loop_statement()
{
   if (debugging) cout << "Parser: entering loop_statement" << endl;

   scan->must_be(symbol::loop_sym);
   statement_list();
   scan->must_be(symbol::end_sym);
   scan->must_be(symbol::loop_sym);

   if (debugging) cout << "Parser: exiting loop_statement" << endl;
}

// <range> ::= <simple_expr> .. <simple_expr>
void parser::range()
{
   if (debugging) cout << "Parser: entering range" << endl;

   simple_expr();
   scan->must_be(symbol::range_sym);
   simple_expr();

   if (debugging) cout << "Parser: exiting range" << endl;
}

//FINISH
/* <expr> ::= <simple_expr> [ <relop> <simple_expr> ]
*         | <simple_expr> in <range>
*/
void parser::expr()
{
   if (debugging) cout << "Parser: entering expr" << endl;

   simple_expr();
   if(scan->have(symbol::greater_than_sym) || scan->have(symbol::less_than_sym) || scan->have(symbol::equals_sym) ||
      scan->have(symbol::less_or_equal_sym) || scan->have(symbol::greater_or_equal_sym) || scan->have(symbol::not_equals_sym))
   {
      relop();
      simple_expr();
   }
   else if(scan->have(symbol::in_sym))
   {
      scan->must_be(symbol::in_sym);
      range();
   }

   if (debugging) cout << "Parser: exiting expr" << endl;
}

// <relop> ::= > | < | = | <> | <= | >=
void parser::relop()
{
   if (debugging) cout << "Parser: entering relop" << endl;

   if(scan->have(symbol::greater_than_sym) || scan->have(symbol::less_than_sym) || scan->have(symbol::equals_sym) ||
      scan->have(symbol::not_equals_sym) || scan->have(symbol::less_or_equal_sym) || scan->have(symbol::greater_or_equal_sym))
   {
      scan->get_token();
   }
   else
   {
      err->flag(scan->this_token(), 105);
   }

   if (debugging) cout << "Parser: exiting relop" << endl;
}

// <simple_expr> ::= <expr2> { <stringop> <expr2> }*
void parser::simple_expr()
{
   if (debugging) cout << "Parser: entering simple_expr" << endl;

   expr2();
   while(scan->have(symbol::ampersand_sym))
   {
      scan->must_be(symbol::ampersand_sym);
      expr2();
   }

   if (debugging) cout << "Parser: exiting simple_expr" << endl;
}

// <expr2> ::= <term> { { <addop> | or } <term> }*
void parser::expr2()
{
   if (debugging) cout << "Parser: entering expr2" << endl;

   term();
 
   while(scan->have(symbol::plus_sym) || scan->have(symbol::minus_sym) || scan->have(symbol::or_sym))
   {
      if(scan->have(symbol::plus_sym))
      {
         scan->must_be(symbol::plus_sym);
      }
      else if(scan->have(symbol::minus_sym))
      {
         scan->must_be(symbol::minus_sym);   
      }
      else if(scan->have(symbol::or_sym))
      {
         scan->must_be(symbol::or_sym);   
      }
      term();
   }

   if (debugging) cout << "Parser: exiting expr2" << endl;
}

// <term> ::= <factor> { { <multop> | and } <factor> }*
void parser::term()
{
   if (debugging) cout << "Parser: entering term" << endl;

   factor();

   while(scan->have(symbol::asterisk_sym) || scan->have(symbol::slash_sym) || scan->have(symbol::and_sym))
   {
      if(scan->have(symbol::asterisk_sym))
      {
         scan->must_be(symbol::asterisk_sym);
      }
      else if(scan->have(symbol::slash_sym))
      {
         scan->must_be(symbol::slash_sym);
      }
      else if(scan->have(symbol::and_sym))
      {
         scan->must_be(symbol::and_sym);
      }
   }   

   factor();

   if (debugging) cout << "Parser: exiting term" << endl;
}

/* <factor> ::= <primary> [ ** <primary> ]
*           | [ <addop> ] <primary>
*/
void parser::factor()
{
   if (debugging) cout << "Parser: entering factor" << endl;

   primary();
   if(scan->have(symbol::power_sym))
   {
      scan->must_be(symbol::power_sym);
      primary();
   }
   else if(scan->have(symbol::plus_sym) || scan->have(symbol::minus_sym))
   {
      if(scan->have(symbol::plus_sym))
      {
         scan->must_be(symbol::plus_sym);
      }
      else if(scan->have(symbol::minus_sym))
      {
         scan->must_be(symbol::minus_sym);
      }
      primary();
   }

   if (debugging) cout << "Parser: exiting factor" << endl;
}

/* <primary> ::= not <expr>
*            | odd <expr>
*            | ( <simple_expr> )
*            | <ident> [ ( <expr>{ , <expr> }* ) ]
*            | <number>
*            | <string>
*            | <bool>
*/
void parser::primary()
{
   if (debugging) cout << "Parser: entering primary" << endl;

   if(scan->have(symbol::not_sym))
   {
      scan->must_be(symbol::not_sym);
      expr();
   }
   else if(scan->have(symbol::odd_sym))
   {
      scan->must_be(symbol::odd_sym);
      expr();
   }
   else if(scan->have(symbol::left_paren_sym))
   {
      scan->must_be(symbol::left_paren_sym);
      simple_expr();
      scan->must_be(symbol::right_paren_sym);
   }
   else if(scan->have(symbol::identifier))
   {
      scan->must_be(symbol::identifier);
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
         expr();
         while(scan->have(symbol::comma_sym))
         {
            scan->must_be(symbol::comma_sym);
            expr();
         }
         scan->must_be(symbol::right_paren_sym);
      }
   }
   else if(scan->have(symbol::integer))
      scan->must_be(symbol::integer);
   else if(scan->have(symbol::real_sym))
      scan->must_be(symbol::real_sym);
   else if(scan->have(symbol::strng))
      scan->must_be(symbol::strng);
   else if(scan->have(symbol::boolean_sym))
      scan->must_be(symbol::boolean_sym);

   if (debugging) cout << "Parser: exiting primary" << endl;
}

