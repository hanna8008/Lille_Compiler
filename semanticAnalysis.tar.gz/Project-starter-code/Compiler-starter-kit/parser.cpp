/*
*
*    Created by: Hanna Zelis
*
*    Date: December 3, 2023
*
*    Parser / Semantic Analysis
*
*/



#include <iostream>
#include <string>
#include <cctype>
#include <cmath>
#include <list>
#include <vector>

#include "symbol.h"
#include "token.h"
#include "error_handler.h"
#include "scanner.h"
#include "parser.h"
#include "id_table.h"
#include "id_table_entry.h"
//#include "lille_kind.h"
//#include "lille_type.h"

using namespace std;

parser::parser(scanner* scan1, id_table* id_tab1, error_handler* err1)
{
   this->scan = scan1;
   this->err = err1;
   this->id_tab = id_tab1;   
}

// <prog> ::= program <ident> is <block> ;
void parser::prog()
{
   if (debugging) cout << "Parser: entering prog" << endl;

   token* predefined_func;
   token* argument;
   symbol* predefined_sym;
   id_table_entry* func_id;
   id_table_entry* param_id;

   //Int2Real
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("INT2REAL");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, 0, lille_type::type_real);

   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__int2real_arg__");
   param_id = new id_table_entry(argument,lille_type::type_integer,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id);


   //Real2Int
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("REAL2INT");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, 0, lille_type::type_integer);


   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__real2int_arg__");
   param_id = new id_table_entry(argument,lille_type::type_real,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id);


    //Int2string
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("INT2STRING");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, 0, lille_type::type_string); //???


   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__int2string_arg__");
   param_id = new id_table_entry(argument,lille_type::type_integer,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id);


   //String2Int
   predefined_sym = new symbol(symbol::identifier);
   predefined_func = new token(predefined_sym, 0, 0);
   predefined_func->set_identifier_value("STRING2INT");
   func_id = id_tab->enter_id(predefined_func, lille_type::type_func,lille_kind::unknown, 0, 0, lille_type::type_integer); //???


   // Create a token for the parameter of the predefined function
   argument = new token (predefined_sym, 0, 0);
   argument->set_identifier_value("__string2int_arg__");
   param_id = new id_table_entry(argument,lille_type::type_string,lille_kind::value_param,0,0,lille_type::type_unknown);
   // Associate parameter with the function.
   func_id->add_param(param_id); 
   
   
   scan->get_token();

   scan->must_be(symbol::program_sym);
   scan->must_be(symbol::identifier);

    //enter scope here

   scan->must_be(symbol::is_sym);
   block();
if(scan->have(symbol::semicolon_sym))
      {
         (scan->must_be(symbol::semicolon_sym)); 
      }if(scan->have(symbol::end_of_program))
      {
         (scan->must_be(symbol::end_of_program)); 
      }
   //exit scope
   	   
   if (debugging) cout << "Parser: exiting prog" << endl;
}

// <block> ::= { <declaration> }* begin <statement_list> end [ <ident> ]
void parser::block()
{
   if (debugging) cout << "Parser: entering block" << endl;

   while(scan->have(symbol::identifier) || scan->have(symbol::procedure_sym) || scan->have(symbol::function_sym))
      declaration();

   if(scan->have(symbol::begin_sym))
   {
      scan->must_be(symbol::begin_sym); 
   }
   statement_list();
   
if(scan->have(symbol::end_sym))
   {
      scan->must_be(symbol::end_sym); 
   }
   if(scan->have(symbol::identifier))
   {
      scan->must_be(symbol::identifier);

   }

   

   if (debugging) cout << "Parser: exiting block" << endl;
}

/* <declaration> ::= <ident_list> : [ constant ] <type>
*                                 [:=<number> | :=<string> | :=<bool>] ;
*                | procedure <ident> [ ( <param_list> ) ] is <block> ;
*                | function <ident> [(<param_list>)] return <type> is <block> ;
*/
void parser::declaration()
{
   if (debugging) cout << "Parser: entering declaration" << endl;


    int count = 0;
    bool comma_found = false;
    bool const_decl = false;
    id_table_entry* id;
    lille_kind knd;
    lille_type ty;
    symbol sym; 

    float r_const;
    string s_const;
    bool b_const;
    int i_const;

    token* block_name;

    vector<token*> list;

   if (scan->have(symbol::identifier))
   {

      do
      {
         if (scan->have(symbol::identifier))
         {
            scan->must_be(symbol::identifier);
            if(scan->have(symbol::constant_sym))
            {
               list.push_back(scan->this_token());
               scan->must_be(symbol::constant_sym);
               const_decl = true;
               count++;
            }


         }
         comma_found = scan->have(symbol::comma_sym);
         if (comma_found){
            scan->must_be(symbol::comma_sym);
         }

      } while (comma_found);




if(scan->have(symbol::colon_sym))
      {
         (scan->must_be(symbol::colon_sym)); 
      }   if(scan->have(symbol::colon_sym))
      {
         (scan->must_be(symbol::colon_sym)); 
      }

   if(scan->have(symbol::constant_sym))
   {
      const_decl = true;
      knd = lille_kind(lille_kind::constant);
      scan->must_be(symbol::constant_sym);
   }

   else
   {
      knd = lille_kind(lille_kind::variable);
      ty = type(); //refer to type function
   }


   if(const_decl)
   {
      scan->must_be(symbol::becomes_sym);
      sym = scan->this_token()->get_symbol()->get_sym();
      if (symbol::real_num)
      {
         r_const = scan->this_token()->get_real_value();
         if (!ty.is_type(lille_type::type_real)){
            err->flag(scan->this_token(), 111);
         }

      }


      else if (symbol::integer)
      {
         r_const = scan->this_token()->get_integer_value();
         if (!ty.is_type(lille_type::type_integer))
         {
            err->flag(scan->this_token(), 111);
         }
      }
      scan->get_token();
   }


   vector<token*>::iterator ptr=list.begin();


   while((ptr != list.end()) and (count >0))
   {
      token* tok = *ptr;
      id = id_tab->enter_id(tok, ty, knd, id_tab->scope(), 0, lille_type::type_unknown);
      if(const_decl){
         id->fix_const(i_const, r_const, s_const, b_const);
      }
      //ptr=ptr->next;
      ++ptr;
      count--;
   }
   } //end of the whole if statement for the variable declaration
   



   if(scan->have(symbol::becomes_sym))  
   {
      scan->must_be(symbol::becomes_sym);
         if(scan->have(symbol::integer_sym))
            scan->must_be(symbol::integer_sym);
         else if(scan->have(symbol::real_sym))
            scan->must_be(symbol::real_sym);
         else if(scan->have(symbol::string_sym))
            scan->must_be(symbol::string_sym);
         else if(scan->have(symbol::boolean_sym))
            scan->have(symbol::boolean_sym);
   }
   if(scan->have(symbol::colon_sym))
      {
         (scan->must_be(symbol::colon_sym)); 
      }

   

   if(scan->have(symbol::procedure_sym))
   {
      scan->must_be(symbol::procedure_sym);
      if (scan->have(symbol::identifier))
      {
         id = id_tab->enter_id(scan->this_token(), lille_type::type_proc, lille_kind::unknown, id_tab->scope(), 0, lille_type::type_unknown);
         //scan->must_be(symbol::identifier);
      }

      block_name = scan->this_token();

      id_tab->enter_scope();
     
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
         param_list();  //may put in id later, once editing param list
         scan->must_be(symbol::right_paren_sym);
      }

      //semantic analysis - procedure and fucntion
      if(scan->have(symbol::return_sym))
      {
         (scan->must_be(symbol::return_sym)); 
      }
      if (scan->have(symbol::integer_sym))
      {
         id->fix_return_type(lille_type::type_integer);
         scan->must_be(symbol::integer_sym);
      }

      else if (scan->have(symbol::real_sym)) 
      {
         id->fix_return_type(lille_type::type_real);
         scan->must_be(symbol::real_sym);
      }

      else if (scan->have(symbol::string_sym)) 
      {
         id->fix_return_type(lille_type::type_string);
         scan->must_be(symbol::string_sym);
      }

      else if (scan->have(symbol::boolean_sym)) 
      {
         id->fix_return_type(lille_type::type_boolean);
         scan->must_be(symbol::boolean_sym);
      }
/*
      else{
         err->flag(scan->this_token(), 108);    //type expected
      } 
      */ 
      scan->must_be(symbol::is_sym);
      block(); //will add parameters later if necessary
      if(scan->have(symbol::semicolon_sym))
      {
         (scan->must_be(symbol::semicolon_sym)); 
      }

      id_tab->exit_scope();
      /*current_offset = old_offset;

      CODE GEN STUFF

      if (return_count == 0)
         err->flag(scan->this_token(), 109);*/

      if (scan->have(symbol::identifier))
      {
         if (block_name->get_identifier_value() != scan->this_token()->get_identifier_value())
            err->flag(scan->this_token(), 107);

         scan->must_be(symbol::identifier);

      }

   }


   if(scan->have(symbol::function_sym))
   {
      scan->must_be(symbol::function_sym);
      if (scan->have(symbol::identifier))
      {
         id = id_tab->enter_id(scan->this_token(), lille_type::type_func, lille_kind::unknown, id_tab->scope(), 0, lille_type::type_unknown);
         //scan->must_be(symbol::identifier);
      }

      block_name = scan->this_token();

      id_tab->enter_scope();
     
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
         param_list();  //may put in id later, once editing param list
         scan->must_be(symbol::right_paren_sym);
      }

      //PROGRAM 2 ERROR
      if(scan->have(symbol::return_sym))
   {
      scan->must_be(symbol::return_sym);
   }
      if (scan->have(symbol::integer_sym))
      {
         id->fix_return_type(lille_type::type_integer);
         scan->must_be(symbol::integer_sym);
      }

      else if (scan->have(symbol::real_sym)) 
      {
         id->fix_return_type(lille_type::type_real);
         scan->must_be(symbol::real_sym);
      }

      else if (scan->have(symbol::string_sym)) 
      {
         id->fix_return_type(lille_type::type_string);
         scan->must_be(symbol::string_sym);
      }

      else if (scan->have(symbol::boolean_sym)) 
      {
         id->fix_return_type(lille_type::type_boolean);
         scan->must_be(symbol::boolean_sym);
      }
/*
      else{
         err->flag(scan->this_token(), 108);    //type expected
      }*/
      
if(scan->have(symbol::is_sym))
   {
      scan->must_be(symbol::is_sym);
   }      block(); //will add parameters later if necessary
if(scan->have(symbol::colon_sym))
      {
         (scan->must_be(symbol::colon_sym)); 
      }
      id_tab->exit_scope();
      /*current_offset = old_offset;

      CODE GEN STUFF

      if (return_count == 0)
         err->flag(scan->this_token(), 109);*/

      if (scan->have(symbol::identifier))
      {
         if (block_name->get_identifier_value() != scan->this_token()->get_identifier_value())
            err->flag(scan->this_token(), 107);

         scan->must_be(symbol::identifier);

      }

   }


/*
   if(scan->have(symbol::function_sym))
   {
      scan->must_be(symbol::function_sym);
      scan->must_be(symbol::identifier);

      type();    
 
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
         param_list();
         scan->must_be(symbol::right_paren_sym);
      }
      
      scan->must_be(symbol::return_sym);
      type();
      scan->must_be(symbol::is_sym);
      block();
      scan->must_be(symbol::semicolon_sym);     
   }
   */
      
   if (debugging) cout << "Parser: exiting declaration" << endl;
}

// <type> ::= integer | real | string | boolean
lille_type parser::type()
{
   lille_type return_type;

   if (debugging) cout << "Parser: entering type" << endl;
   
   if(scan->have(symbol::integer_sym))
   {
      scan->must_be(symbol::integer_sym);
      return_type = lille_type::type_integer;
   }
   else if(scan->have(symbol::real_sym))
   {
      scan->must_be(symbol::real_sym);
      return_type = lille_type::type_real;
   }
   else if(scan->have(symbol::string_sym))
   {
      scan->must_be(symbol::string_sym);
      return_type = lille_type::type_string;
   }
   else if(scan->have(symbol::boolean_sym))
   {
      scan->must_be(symbol::boolean_sym);
      return_type = lille_type::type_boolean;
   }

   return return_type;

   if (debugging) cout << "Parser: exiting type" << endl;
   


} //end of declaration function




// <param_list> ::= <param> { ; <param> }*
void parser::param_list()
{
   if (debugging) cout << "Parser: entering param_list" << endl;

   param();
   while(scan->have(symbol::semicolon_sym))
   {
      scan->must_be(symbol::semicolon_sym);
      param();
   }

  //semantic analysis
  
   // Initializing variables for parameter building
    int count = 0;
    lille_type ty;
    lille_kind knd;

    bool comma_found = false;
    bool const_decl = false;
    id_table_entry* id;

    symbol sym; 

    float r_const;
    string s_const;
    bool b_const;
    int i_const;

    token* block_name;

    vector<token*> list;

    // Loop to build a list of parameters
    /*while (scan->have(symbol::identifier)) {
        // Get the parameter type
        ty = type();
        // Determine the parameter kind (value or ref)
        if (scan->have(symbol::value_sym)) {
            scan->must_be(symbol::value_sym);
            knd = lille_kind::value_parameter;
        } else if (scan->have(symbol::ref_sym)) {
            scan->must_be(symbol::ref_sym);
            knd = lille_kind::ref_parameter;
        } else {
            knd = lille_kind::unknown;
        }

        // Creating parameter ID and adding it to the ID table
        id_table_entry* param_id = new id_table_entry(scan->this_token(), ty, knd, id_tab->scope(), current_offset, lille_type::type_unknown);
        id_tab->add_table_entry(param_id);
        id->add_param(param_id);
        
        count++;

        // Move to the next token if available
        scan->get_token();
        
        // Check if there are more parameters to process
        if (scan->have(symbol::comma_sym)) {
            scan->must_be(symbol::comma_sym);
        } else {
            break;
        }
    }*/

    // Perform additional operations if needed based on the created parameter list
    // …
    // …
    // …
    // …
    // …
    // …


    // Loop through the parameters to finalize their entries
    
    /*while ((ptr != NULL) && (count > 0)) {
        param_id = new id_table_entry(ptr->val, ty, knd, id_tab->scope(), 0, lille_type::type_unknown);
        id_tab->add_table_entry(param_id);
        id->add_param(param_id);
        count--;

        if (ptr->next != NULL) {
            ptr = ptr->next;
        }
    }*/

   vector<token*>::iterator ptr=list.begin();
   
   while((ptr != list.end()) and (count >0))
   {
      token* tok = *ptr;
      id = id_tab->enter_id(tok, ty, knd, id_tab->scope(), 0, lille_type::type_unknown);
      if(const_decl)
         id->fix_const(i_const, r_const, s_const, b_const);
      //ptr=ptr->next;
      ++ptr;
      count--;
   }
    

   if (debugging) cout << "Parser: entering param_list" << endl;
}

// <param> ::= <ident_list> : <param_kind> <type>
void parser::param()
{
   if (debugging) cout << "Parser: entering param" << endl;
   
   ident_list();
if(scan->have(symbol::colon_sym))
      {
         (scan->must_be(symbol::colon_sym)); 
      }
         param_kind();
   type();

   if (debugging) cout << "Parser: exiting param" << endl;
}

// <ident_list> ::= <ident> { , <ident> }*
void parser::ident_list()
{
   if (debugging) cout << "Parser: entering ident_list" << endl;

   scan->must_be(symbol::identifier);
   while (scan->have(symbol::comma_sym))
   {
      scan->must_be(symbol::comma_sym);
      scan->must_be(symbol::identifier);
   }

   if (debugging) cout << "Parser: exiting ident_list" << endl;
}

// <param_kind> ::= value | ref 
void parser::param_kind()
{
   if (debugging) cout << "Parser: entering param_kind" << endl;

   if(scan->have(symbol::value_sym))
   {
      scan->must_be(symbol::value_sym);
   }
   else if(scan->have(symbol::ref_sym))
   {
      scan->must_be(symbol::ref_sym);
   }

   if (debugging) cout << "Parser: exiting param_kind" << endl;
}

// <statement_list> ::= <statement> ; { <statement> ; }*
void parser::statement_list()
{
   if (debugging) cout << "Parser: entering statement_list" << endl;

   statement();
   //scan->must_be(symbol::semicolon_sym);
   while(scan->have(symbol::identifier) || scan->have(symbol::exit_sym) || scan->have(symbol::return_sym) || scan->have(symbol::read_sym) ||
         scan->have(symbol::write_sym) || scan->have(symbol::writeln_sym) || scan->have(symbol::if_sym) || scan->have(symbol::loop_sym) ||
         scan->have(symbol::for_sym) || scan->have(symbol::while_sym) || scan->have(symbol::null_sym))
   {
      statement();
      scan->must_be(symbol::semicolon_sym);
      //scan->get_token();
   }

   if (debugging) cout << "Parser: exiting statement_list" << endl;
}

/* <statement> ::= <simple_statement>
*             | <compound_statement>
*/
void parser::statement()
{
   if (debugging) cout << "Parser: entering statement" << endl;

   if(scan->have(symbol::if_sym) || scan->have(symbol::while_sym) ||
      scan->have(symbol::for_sym) || scan->have(symbol::loop_sym))
   {
      compound_statement();
   }
   else if(scan->have(symbol::identifier) || scan->have(symbol::exit_sym) || scan->have(symbol::return_sym) || scan->have(symbol::read_sym) ||
         scan->have(symbol::write_sym) || scan->have(symbol::writeln_sym) || scan->have(symbol::null_sym)) 
   {
      simple_statement();
   }

   if (debugging) cout << "Parser: exiting statement" << endl;
}

//FINISH

/* <simple_statement> ::= <ident> [ ( <expr> { , <expr> }* ) ]
*                     | <ident> := <expr>
*                     | exit [ when <expr> ]
*                     | return [ <expr> ]
*                     | read [ ( ] <ident> { , <ident> }* [ ) ]
*                     | write [ ( ] <expr> { , <expr> }* [ ) ]
*                     | writeln [ ( ] [ <expr> { , <expr> }* ] [ ) ]
*                     | null
*/
lille_type parser::simple_statement()
{
   if (debugging) cout << "Parser: entering simple_statement" << endl;

   token* tok;
   id_table_entry* id_info;

   id_table_entry* id;

   lille_kind knd;
   lille_type return_type;

   //id_tab->dump_id_table(true);

   if(scan->have(symbol::identifier))
   {
      tok = scan->this_token(); 
      id_info = id_tab->lookup(tok);
      return_type = id->tipe();
      knd = id->kind();
      scan->must_be(symbol::identifier);

    if (id_info != nullptr) 
    {

      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);

         if (!id_info->tipe().is_type(lille_type::type_proc)) //different in his code assignment, id with parentheses stuff
            err->flag(tok, 90);

         expr();
         while(scan->have(symbol::comma_sym))
         {
            scan->must_be(symbol::comma_sym);
            expr();
         }

         ident_list(); //may have to edit aprameters later

         scan->must_be(symbol::right_paren_sym);
      }


      else if(scan->have(symbol::becomes_sym))
      {
         cout << "PRE SEG FAULT 1" << endl;
         
        if (!(id_info->kind().is_kind(lille_kind::variable) or id_info->kind().is_kind(lille_kind::ref_param)))
            err->flag(tok, 85);
        cout << "PRE SEG FAULT 22" << endl;
        scan->must_be(symbol::becomes_sym);
         
        //expr();

         if (scan->have(symbol::not_sym) or scan->have(symbol::odd_sym) or scan->have(symbol::left_paren_sym) or scan->have(symbol::identifier) or scan->have(symbol::integer) or scan->have(symbol::real_num) or scan->have(symbol::strng) or scan->have(symbol::true_sym) or scan->have(symbol::false_sym) or scan->have(symbol::plus_sym) or scan->have(symbol::minus_sym)) //         if (expr_first_symbols.member (scan->this_token()->get_symbol()->get_sym()))
         {  
            lille_type exp_ty = expr(); 
            if (!id_info->tipe().is_equal(exp_ty))
            { 
               err->flag(scan->this_token(), 93);
            }
            /*if((id_info->kind().is_kind(lille_kind::ref_param)) or (id_info->kind().is_kind(lille_kind::variable)))
               trace_write(id_info, true);

            ^code gen^ ???

            */

            else
            {
               err->flag(scan->this_token(), 92);
            }

         }

         else{
            err->flag(tok, 91); 
         }

      }
    }
      //break;
   }


   else if(scan->have(symbol::exit_sym))
   {
      scan->must_be(symbol::exit_sym);
      if(scan->have(symbol::when_sym))
      {
         scan->must_be(symbol::when_sym);
         expr();
      }
   }

   else if(scan->have(symbol::return_sym))
   {
      scan->must_be(symbol::return_sym);
      if(scan->have(symbol::identifier) || scan->have(symbol::integer) || scan->have(symbol::real_sym) ||
         scan->have(symbol::strng) || scan->have(symbol::boolean_sym))
      {
         expr();
      }
   }

   else if(scan->have(symbol::read_sym))
   {
      scan->must_be(symbol::read_sym);
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
      }
      scan->must_be(symbol::identifier);
      while(scan->have(symbol::comma_sym))
      {
         scan->must_be(symbol::comma_sym);
         scan->must_be(symbol::identifier);
      }
      if(scan->have(symbol::right_paren_sym))
      {
         scan->must_be(symbol::right_paren_sym);
      }
   }
   else if(scan->have(symbol::write_sym))
   {
      scan->must_be(symbol::write_sym);
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
      }
      expr();
      while(scan->have(symbol::comma_sym))
      {
         scan->must_be(symbol::comma_sym);
         expr();
      }
      if(scan->have(symbol::right_paren_sym))
      {
         scan->must_be(symbol::right_paren_sym);
      }
   }

   else if(scan->have(symbol::writeln_sym))
   {
      scan->must_be(symbol::writeln_sym);
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
      }

      if(scan->have(symbol::identifier) || scan->have(symbol::integer) || scan->have(symbol::real_sym) ||
         scan->have(symbol::not_sym) || scan->have(symbol::boolean_sym) || scan->have(symbol::strng) || scan->have(symbol::odd_sym))
      {
         expr();
         while(scan->have(symbol::comma_sym))
         {
            scan->must_be(symbol::comma_sym);
            expr();
         }
      }
    
      if(scan->have(symbol::right_paren_sym))
      {
         scan->must_be(symbol::right_paren_sym);
      }
   }

   else if(scan->have(symbol::null_sym))
   {
      scan->must_be(symbol::null_sym);
   }
         
   if (debugging) cout << "Parser: exiting simple_statement" << endl;

   return return_type;
}

/* <compound_statement> ::= <if_statement>
*                       | <loop_statement>
*                       | <for_statement>
*                       | <while_statement>
*/
void parser::compound_statement()
{
   if (debugging) cout << "Parser: entering compoun_statement" << endl;

   if(scan->have(symbol::if_sym))
   {
      if_statement();
   }
   else if(scan->have(symbol::loop_sym))
   {
      loop_statement();
   }
   else if(scan->have(symbol::for_sym))
   {
      for_statement();
   }
   else if(scan->have(symbol::while_sym))
   {
      while_statement();
   }

   if (debugging) cout << "Parser: exiting compound_statement" << endl;
}

/* <if_statement> ::= if <expr> then <statement_list>
*                 { elsif <expr> then <statement_list> }*
*                 [ else <statement_list> ]
*                 end if
*/
void parser::if_statement()
{
   if (debugging) cout << "Parser: entering if_statement" << endl;

   scan->must_be(symbol::if_sym);
   expr();
   scan->must_be(symbol::then_sym);
   statement_list();
   
   while(scan->have(symbol::elsif_sym))
   {
      scan->must_be(symbol::elsif_sym);
      expr();
      scan->must_be(symbol::then_sym);
      statement_list();
   }
   
   if(scan->have(symbol::else_sym))
   {
      scan->must_be(symbol::else_sym);
      statement_list();
   }
  
   scan->must_be(symbol::end_sym);
   scan->must_be(symbol::if_sym);

   if (debugging) cout << "Parser: exiting if_statement" << endl;

}

// <while_statement> ::= while <expr> <loop_statement>
void parser::while_statement()
{
   if (debugging) cout << "Parser: entering while_statement" << endl;

   scan->must_be(symbol::while_sym);
   expr();
   loop_statement();

   if (debugging) cout << "Parser: exiting while_statement" << endl;
}

// <for_statement> ::= for <ident> in [ reverse ] <range> <loop_statement>
void parser::for_statement()
{
   if (debugging) cout << "Parser: entering for_statement" << endl;

   scan->must_be(symbol::for_sym);
   scan->must_be(symbol::identifier);
   scan->must_be(symbol::in_sym);
   if(scan->have(symbol::reverse_sym))
   {
      scan->must_be(symbol::reverse_sym);
   }
   
   range();
   loop_statement(); 
  
   if (debugging) cout << "Parser: exiting for_statement" << endl;
}

// <loop_statement> ::= loop <statement_list> end loop
void parser::loop_statement()
{
   if (debugging) cout << "Parser: entering loop_statement" << endl;

/*

 if (scan->have(symbol::loop_sym)) {
        scan->must_be(symbol::loop_sym);
    }

  statement_list();

    // Parse the statement list within the loop
    while(scan->have(symbol::identifier) || scan->have(symbol::exit_sym) || scan->have(symbol::return_sym) || scan->have(symbol::read_sym) ||
         scan->have(symbol::write_sym) || scan->have(symbol::writeln_sym) || scan->have(symbol::if_sym) || scan->have(symbol::loop_sym) ||
         scan->have(symbol::for_sym) || scan->have(symbol::while_sym) || scan->have(symbol::null_sym))
   {
      
        // Check if an assignment to the loop control variable is attempted
        if (scan->have(symbol::identifier)) {
            token* currentToken = scan->this_token();
            if (currentToken->get_identifier_value() == "i") {
                // Throw an error for assigning to the loop control variable
                err->flag(currentToken, 1001); // Error code 1001: Assignment to loop control variable 'i'
            }
        }
    }

    if (scan->have(symbol::end_sym)) {
        scan->must_be(symbol::end_sym);
    }

    if (scan->have(symbol::loop_sym)) {
        scan->must_be(symbol::loop_sym);
    }


  statement_list();


*/
if(scan->have(symbol::loop_sym))
   {
      scan->must_be(symbol::loop_sym);
   }   statement_list();

   if (scan->have(symbol::identifier)) {
            token* currentToken = scan->this_token();
            if (currentToken->get_identifier_value() == "i") {
                // Throw an error for assigning to the loop control variable
                err->flag(currentToken, 1001); // Error code 1001: Assignment to loop control variable 'i'
            }
        }
if(scan->have(symbol::end_sym))
   {
      scan->must_be(symbol::end_sym);
   }if(scan->have(symbol::loop_sym))
   {
      scan->must_be(symbol::loop_sym);
   }

   
   if (debugging) cout << "Parser: exiting loop_statement" << endl;
}


// <range> ::= <simple_expr> .. <simple_expr>
void parser::range()
{
   if (debugging) cout << "Parser: entering range" << endl;

   simple_expr();
if(scan->have(symbol::range_sym))
   {
      scan->must_be(symbol::range_sym);
   }   simple_expr();

   if (debugging) cout << "Parser: exiting range" << endl;
}

//FINISH
/* <expr> ::= <simple_expr> [ <relop> <simple_expr> ]
*         | <simple_expr> in <range>
*/
lille_type parser::expr()
{
   if (debugging) cout << "Parser: entering expr" << endl;

   lille_type return_type;


   return_type = simple_expr();
   if(scan->have(symbol::greater_than_sym) || scan->have(symbol::less_than_sym) || scan->have(symbol::equals_sym) ||
      scan->have(symbol::less_or_equal_sym) || scan->have(symbol::greater_or_equal_sym) || scan->have(symbol::not_equals_sym))
   {
      relop();
      simple_expr(); //maybe return_type
   }
   else if(scan->have(symbol::in_sym))
   {
      scan->must_be(symbol::in_sym);
      range();
   }

   if (debugging) cout << "Parser: exiting expr" << endl;

   return return_type;

}

// <relop> ::= > | < | = | <> | <= | >=
void parser::relop()
{
   if (debugging) cout << "Parser: entering relop" << endl;

   if(scan->have(symbol::greater_than_sym) || scan->have(symbol::less_than_sym) || scan->have(symbol::equals_sym) ||
      scan->have(symbol::not_equals_sym) || scan->have(symbol::less_or_equal_sym) || scan->have(symbol::greater_or_equal_sym))
   {
      scan->get_token();
   }
   /*
   else
   {
      err->flag(scan->this_token(), 105);
   }
*/ 
   if (debugging) cout << "Parser: exiting relop" << endl;
}

// <simple_expr> ::= <expr2> { <stringop> <expr2> }*
lille_type parser::simple_expr()
{
   if (debugging) cout << "Parser: entering simple_expr" << endl;

   lille_type return_type = expr2();
   while(scan->have(symbol::ampersand_sym))
   {
      scan->must_be(symbol::ampersand_sym);
      expr2(); //maybe change
   }

   if (debugging) cout << "Parser: exiting simple_expr" << endl;

   return return_type;
}

// <expr2> ::= <term> { { <addop> | or } <term> }*
lille_type parser::expr2()
{
   if (debugging) cout << "Parser: entering expr2" << endl;

   lille_type return_type;

   return_type = term();
 
   while(scan->have(symbol::plus_sym) || scan->have(symbol::minus_sym) || scan->have(symbol::or_sym))
   {
      if(scan->have(symbol::plus_sym))
      {
         scan->must_be(symbol::plus_sym);
      }
      else if(scan->have(symbol::minus_sym))
      {
         scan->must_be(symbol::minus_sym);   
      }
      else if(scan->have(symbol::or_sym))
      {
         scan->must_be(symbol::or_sym);   
      }
      term(); //maybe
   }

   if (debugging) cout << "Parser: exiting expr2" << endl;

   return return_type;
}

// <term> ::= <factor> { { <multop> | and } <factor> }*
lille_type parser::term()
{
   if (debugging) cout << "Parser: entering term" << endl;

   lille_type return_type;

   return_type = factor();

   while(scan->have(symbol::asterisk_sym) || scan->have(symbol::slash_sym) || scan->have(symbol::and_sym))
   {
      if(scan->have(symbol::asterisk_sym))
      {
         scan->must_be(symbol::asterisk_sym);
      }
      else if(scan->have(symbol::slash_sym))
      {
         scan->must_be(symbol::slash_sym);
      }
      else if(scan->have(symbol::and_sym))
      {
         scan->must_be(symbol::and_sym);
      }
   }   

   factor();   //maybe here

   if (debugging) cout << "Parser: exiting term" << endl;

   return return_type;
}

/* <factor> ::= <primary> [ ** <primary> ]
*           | [ <addop> ] <primary>
*/
lille_type parser::factor()
{
   if (debugging) cout << "Parser: entering factor" << endl;

   lille_type return_type;

   return_type = primary();
   if(scan->have(symbol::power_sym))
   {
      scan->must_be(symbol::power_sym);
      primary();
   }
   else if(scan->have(symbol::plus_sym) || scan->have(symbol::minus_sym))
   {
      if(scan->have(symbol::plus_sym))
      {
         scan->must_be(symbol::plus_sym);
      }
      else if(scan->have(symbol::minus_sym))
      {
         scan->must_be(symbol::minus_sym);
      }
      primary(); //maybe chance
   }

   if (debugging) cout << "Parser: exiting factor" << endl;

   return return_type;
}

/* <primary> ::= not <expr>
*            | odd <expr>
*            | ( <simple_expr> )
*            | <ident> [ ( <expr>{ , <expr> }* ) ]
*            | <number>
*            | <string>
*            | <bool>
*/ 
lille_type parser::primary()
{
   if (debugging) cout << "Parser: entering primary" << endl;

   lille_type return_type;

   if(scan->have(symbol::not_sym))
   {
      scan->must_be(symbol::not_sym);
      expr();
   }
   else if(scan->have(symbol::odd_sym))
   {
      scan->must_be(symbol::odd_sym);
      expr();
   }
   else if(scan->have(symbol::left_paren_sym))
   {
      scan->must_be(symbol::left_paren_sym);
      simple_expr();
      scan->must_be(symbol::right_paren_sym);
   }
   else if(scan->have(symbol::identifier))
   {
      scan->must_be(symbol::identifier);
      if(scan->have(symbol::left_paren_sym))
      {
         scan->must_be(symbol::left_paren_sym);
         expr();
         while(scan->have(symbol::comma_sym))
         {
            scan->must_be(symbol::comma_sym);
            expr();
         }
         scan->must_be(symbol::right_paren_sym);
      }
   }
   else if(scan->have(symbol::integer)) 
   {
      scan->must_be(symbol::integer);
      return_type = lille_type::type_integer;
   }

   else if(scan->have(symbol::real_sym))
   {
      scan->must_be(symbol::real_sym);
      return_type = lille_type::type_real;
   }

   else if(scan->have(symbol::strng))
   {
      scan->must_be(symbol::strng);
      return_type = lille_type::type_string;
   }

   else if(scan->have(symbol::boolean_sym))
   {
      scan->must_be(symbol::boolean_sym);
      return_type = lille_type::type_boolean;
   }

   if (debugging) cout << "Parser: exiting primary" << endl;

   return return_type;
}